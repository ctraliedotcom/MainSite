# jsTDA
Topological Data Analysis Tools in Javascript.  Enabled by Uli Bauer's Ripser code

## Compiling
emcc --bind -o ripser.js ripser.cpp
