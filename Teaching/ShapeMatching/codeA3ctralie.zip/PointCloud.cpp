/*Programmer: Chris Tralie
*Purpose: To create an organized class to store a point cloud,
*and to create member functions that can calculate descriptors
*of this point cloud*/

#include <iostream>
#include <string>
#include <vector>
#include <time.h>
#include <stdio.h>

#include <tnt.h>
#include <jama_svd.h>

#include "PointCloud.h"

using namespace std;

static vector<R3Vector> sphereDirs;

//Open the file and take samples, using the external
//program "pointsample.exe"
void PointCloud::ResamplePoints(char* fileprefix, int npoints) {
//NOTE: It's up to the user to make sure to resample everything
//if the sample size is changed (otherwise, descriptors will be inconsistent)
//This function is just for convenience, so that things only get resampled
//if the user sepcifies (so that during debugging many tests can be run on 
//the same data sets without having to resample every time)
	char plyname[256];
	char ptsname[256];
	char command[1000];

	sprintf(plyname, "%s.ply", fileprefix);
	sprintf(ptsname, "%s.pts", fileprefix);
	sprintf(command, "pointsample %s %i %s", plyname, npoints, ptsname);
	
	printf("RESAMPLING %s ...\n", plyname);
	printf("%s\n", command);
	system((const char*)command);
	printf("\n\n");
}

//The constructor, which will load in a model from a file (and resample
//it if necessary)
PointCloud::PointCloud(char* fileprefix, char* mclass, int npoints, bool resample) {
	strcpy(modelClass, mclass);
	strcpy(fullname, fileprefix);
	
	//Check to see if the file has already been sampled
	char ptsname[256];
	sprintf(ptsname, "%s.pts", fileprefix);

	FILE* fin = fopen(ptsname, "r");
	if (fin == NULL || resample) {
		ResamplePoints(fileprefix, npoints);
		fin = fopen(ptsname, "r");
		if (fin == NULL) {
			fprintf(stderr, "ERROR Sampling points or opening points sampled file %s\n", ptsname);
			return;
		}
	}

	CM = R3null_point;
	//Now load in all of the sampled points and their normals into the
	//data structurs in this class
	while (!feof(fin)) {
		double p1, p2, p3, n1, n2, n3;
		fscanf(fin, "%lf %lf %lf %lf %lf %lf", &p1, &p2, &p3, &n1, &n2, &n3);
		R3Point point(p1, p2, p3);
		R3Vector normal(n1, n2, n3);
		normal.Normalize();
		points.push_back(point);
		normals.push_back(normal);
		CM += point;
	}
	fclose(fin);
	CM /= (double)points.size();

	//Now subtract off the center of mass from all of the points
	for (size_t i = 0; i < points.size(); i++) {
		points[i].SetX(points[i].X() - CM.X());
		points[i].SetY(points[i].Y() - CM.Y());
		points[i].SetZ(points[i].Z() - CM.Z());
	}

	//Now calculate the RMS distance
	double distrms = 0.0;
	for (size_t i = 0; i < points.size(); i++) {
		R3Vector v = points[i].Vector();
		distrms += v.Dot(v);
	}
	distrms = sqrt(distrms / (double)points.size());
	//Scale the points by 1/distrms to normalize by scale
	for (size_t i = 0; i < points.size(); i++) {
		points[i] /= distrms;
		//printf("%f %f %f\n", points[i].X(), points[i].Y(), points[i].Z());
	}
}

//The D2 descriptor
void PointCloud::getD2(int nsamples) {
	srand(time(NULL));//Seed for the random number generator
	double binMult = (double)D2BINS / (double)MAXD2;
	int npoints = (int)points.size();
	for (int i = 0; i < D2BINS; i++)
		d2[i] = 0;
	for (int i = 0; i < nsamples; i++) {
		int index1 = rand() % npoints, index2 = rand() % npoints;
		R3Point P1 = points[index1];
		R3Point P2 = points[index2];
		R3Vector diff = P1 - P2;
		double dist = diff.Length();
		//Now figure out which bin in the histogram this
		//sample falls into (round it to the nearest bin)
		int bin = (int)floor(binMult * dist + 0.5);
		bin %= D2BINS;//Make sure this doesn't overshoot the max bin cap
		d2[bin]++;
	}
}

//The shell descriptor
void PointCloud::getShell() {
	double binMult = (double)SHELLBINS / (double)MAXSHELL;
	for (size_t i = 0; i < points.size(); i++) {
		double dist = points[i].Vector().Length();//Distance from the origin
		int bin = (int)floor(binMult * dist + 0.5);
		if (bin >= SHELLBINS)
			bin = SHELLBINS - 1;
		shell[bin]++;
	}
}

//NOTE: This function also does the work of getShell(), so there's no need
//to call both if all of the descriptors are being calculated in tandem
void PointCloud::getShellPCA() {
	double binMult = (double)SHELLBINS / (double)MAXSHELL;
	vector<R3Point> shellPoints[SHELLBINS];
	for (int i = 0; i < 3*SHELLBINS; i++) 
		shellPCA[i] = 0.0;

	for (size_t i = 0; i < points.size(); i++) {
		double dist = points[i].Vector().Length();//Distance from the origin
		int bin = (int)floor(binMult * dist + 0.5);
		if (bin >= SHELLBINS)
			bin = SHELLBINS - 1;
		shell[bin]++;
		shellPoints[bin].push_back(points[i]);
	}

	//Now compute the 3 principal components using SVD
	for (int i = 0; i < SHELLBINS; i++) {
		int npoints = (int)shellPoints[i].size();
		if (npoints <= 0) {
			//If there are no points, make sure not to continue, because
			//TNT's SVD will crash (learned this the hard way)
			//Instead, keep all of the singular values at zero
			continue;
		}

		//Fill in the rows of an nx3 matrix (where n is the number
		//of points that fell into this shell), where each row
		//in the matrix holds the (x, y, z) coordinates of a single point
		TNT::Array2D<double> pointrows(npoints, 3, 0.0);
		for (int j = 0; j < npoints; j++) {
			pointrows[j][0] = (shellPoints[i])[j].X();
			pointrows[j][1] = (shellPoints[i])[j].Y();
			pointrows[j][2] = (shellPoints[i])[j].Z();
		}

		//Compute the SVD and get the 3 principal components 
		//(the singular values listed in decreasing order)
		JAMA::SVD<double> svd(pointrows);
		TNT::Array1D<double> singValues;
		svd.getSingularValues(singValues);

		//Fill the singular values into the descriptor, in descending order
		//(so that the strength of the strongest principal component/
		//direction of variation shows up first in the descriptor)
		for (int k = 0; k < 3; k++) {
			if (singValues[k] < 0.001) //Put a lower bound on what a singular
				//value can be (weird things were happening with floating point
				//with too small numbers)
				break;	
			shellPCA[i*3 + k] = singValues[k];
		}
	}
}

//Normalize the point to the sphere and find the closest point
//in the set of equally spaced points in "sphereDirs"
//Note that this closest point is also the point with which this
//makes the greatest dot product
int getClosestSector(R3Point P) {
	int greatestindex = 0;
	double greatestdotprod = 0.0;
	R3Vector V = P.Vector();
	for (size_t i = 0; i < sphereDirs.size(); i++) {
		double d = sphereDirs[i].Dot(V);
		if (d > greatestdotprod) {
			greatestdotprod = d;
			greatestindex = (int)i;
		}
	}
	return greatestindex;
}

void loadSphereDirs() {
	//There's an external file "sampledsphere32.txt" that stores 32 
	//samples on the surface of a sphere that are close to being uniformly
	//spaced, so load that in
	const char* spherefilename = "sampledsphere32.txt";
	FILE* fin = fopen(spherefilename, "r");
	if (fin == NULL) {
		fprintf(stderr, "ERROR opening sphere sample file %s\n", spherefilename);
		return;
	}
	while (!feof(fin)) {
		double x1, x2, x3;
		fscanf(fin, "%lf%lf%lf", &x1, &x2, &x3);
		R3Vector v(x1, x2, x3);
		v.Normalize();//Just in case
		sphereDirs.push_back(v);
	}
}

//Use to help sort the sectors over all shells
bool SectorComparator(struct SectorCount elem1, struct SectorCount elem2)
{
   return elem1.count < elem2.count;
}


//Do the Sectors and Shells descriptor (actually calculate both
//flavors of this descriptor; sorting within each shell and sorting
//over all of the shells)
void PointCloud::getShellSectors() {
	if (sphereDirs.size() == 0)
		loadSphereDirs();

	double binMult = (double)SHELLBINS / (double)MAXSHELL;
	vector<R3Point> shellPoints[SHELLBINS];
	for (size_t i = 0; i < points.size(); i++) {
		double dist = points[i].Vector().Length();//Distance from the origin
		int shell = (int)floor(binMult * dist + 0.5);
		if (shell >= SHELLBINS)
			shell = SHELLBINS - 1;
		shellPoints[shell].push_back(points[i]);
	}

	for (size_t shell = 0; shell < SHELLBINS; shell++) {
		shellSectors[shell].clear();
		shellSectors[shell].resize(sphereDirs.size());
		for (size_t i = 0; i < shellSectors[shell].size(); i++)
			(shellSectors[shell])[i] = 0;
		for (size_t i = 0; i < shellPoints[shell].size(); i++) {
			int sector = getClosestSector((shellPoints[shell])[i]);
			(shellSectors[shell])[sector]++;
		}
	}
	
	//Sort by which sectors along the sphere have the most points overall
	vector<struct SectorCount> sectorCounts;
	sectorCounts.resize(sphereDirs.size());
	for (size_t sector = 0; sector < sectorCounts.size(); sector++) {
		sectorCounts[sector].count = 0;
		sectorCounts[sector].sector = (int)sector;
	}
	for (size_t shell = 0; shell < SHELLBINS; shell++) {
		for (size_t sector = 0; sector < sectorCounts.size(); sector++) {
			sectorCounts[sector].count++;
		}
	}
	sort(sectorCounts.begin(), sectorCounts.end(), SectorComparator);
	for (size_t shell = 0; shell < SHELLBINS; shell++) {
		shellSectorsOverall[shell].clear();
		shellSectorsOverall[shell].resize(sphereDirs.size());
		for (size_t i = 0; i < sectorCounts.size(); i++) {
			int sector = sectorCounts[i].sector;
			shellSectorsOverall[shell][i] = shellSectors[shell][sector];
		}
	}

	//Sort within each shell individually
	for (size_t shell = 0; shell < SHELLBINS; shell++) {
		sort(shellSectors[shell].begin(), shellSectors[shell].end());
	}
}

//Compute the EGI after doing rotational normalization with PCA
void PointCloud::getEGI() {
	//Compute the principal axes of the points
	int npoints = (int)points.size();
	TNT::Array2D<double> pointrows(npoints, 3, 0.0);
	for (int i = 0; i < npoints; i++) {
		pointrows[i][0] = points[i].X();
		pointrows[i][1] = points[i].Y();
		pointrows[i][2] = points[i].Z();
	}

	//Compute the SVD and get the 3 principal components 
	//(the singular values listed in decreasing order)
	JAMA::SVD<double> svd(pointrows);
	TNT::Array2D<double> V;
	svd.getV(V);
	//The columns of V hold an orthonormal basis of principal
	//directions for the points.  Copy V over to a matrix
	//object in the 426 R3 library as the transpose
	//(the transpose will give the inverse of the matrix, which
	//is what is needed to make the points a linear combination
	//of principal axes)
	R3Matrix M(V[0][0], V[1][0], V[2][0], 0, 
			   V[0][1], V[1][1], V[2][1], 0,
			   V[0][2], V[1][2], V[2][2], 0,
			   0, 0, 0, 1);

	//Now form a new point set, with each point multiplied by
	//the matrix M to align it with the principal directions
	for (int i = 0; i < npoints; i++) {
		R3Point P = M * points[i];
		R3Vector N = M * normals[i];
		aapoints.push_back(P);
		aanormals.push_back(N);
	}

	//Now quantize the points to different bins within shells
	//according to where their normals are oriented
	if (sphereDirs.size() == 0)
		loadSphereDirs();

	EGINormals.resize(sphereDirs.size());
	for (size_t i = 0; i < aanormals.size(); i++) {
		EGINormals[getClosestSector(aanormals[i].Point())]++;
	}
}