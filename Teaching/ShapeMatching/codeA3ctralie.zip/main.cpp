//Programmer: Chris Tralie
//Purpose: To provide a main program where a user can choose which models
//to load in and which descriptors to compare them with.  This program should
//also output precision recall graphs for each descriptor that the user
//chooses to run

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <vector>
#include <algorithm>

#include "PointCloud.h"
#include <tnt.h>

#define D2 0
#define SHELL 1
#define SHELLPCA 2
#define SHELLSECTORS 3
#define SHELLSECTORSOVERALL 4
#define EGI 5

using namespace std;

bool verbose = false;
bool resample = false;
bool doD2 = false;
bool doShell = false;
bool doShellPCA = false;
bool doShellSectors = false;
bool doShellSectorsOverall = false;
bool doEGI = false;

int nmodels;//Number of models per type
int npoints;//Number of point/normal samples per model
int d2Samples;//The number of random samples to take with
//the d2 descriptor

vector<PointCloud> models;

void printUsage() {
	cerr << "Usage: Descriptors3D <models path> <types.txt> <num models per type> [-v -resample [npoints] -d2 [nsamples] -shell -shellPCA -shellSectors -shellSectorsOverall -egi]\n";
	exit(0);
}

void parseArgs(int argc, char** argv) {
	if (argc < 4)
		printUsage();

	//First read in the optional parameters that tell what to do with
	//the point clouds
	int argvindex = 4;
	argc -= 4;
	while (argc > 0) {
		//[-v -d2 [nsamples] -shell -shellPCA]	
		if (strcmp(argv[argvindex], "-v") == 0) {
			verbose = true;
			argc--;argvindex++;
		}
		else if (strcmp(argv[argvindex], "-resample") == 0) {
			if (argc < 2)
				printUsage();
			resample = true;
			argvindex++;
			npoints = atoi(argv[argvindex]);
			argc -= 2;argvindex++;
		}
		else if (strcmp(argv[argvindex], "-d2") == 0) {
			if (argc < 2)
				printUsage();

			doD2 = true;
			argvindex++;
			d2Samples = atoi(argv[argvindex]);
			argc -= 2;argvindex++;
		}
		else if (strcmp(argv[argvindex], "-shell") == 0) {
			doShell = true;
			argc--;argvindex++;
		}
		else if (strcmp(argv[argvindex], "-shellPCA") == 0) {
			doShellPCA = true;
			argc--;argvindex++;
		}
		else if (strcmp(argv[argvindex], "-shellSectors") == 0) {
			doShellSectors = true;
			argc--;argvindex++;
		}
		else if (strcmp(argv[argvindex], "-shellSectorsOverall") == 0) {
			doShellSectorsOverall = true;
			argc--;argvindex++;
		}
		else if (strcmp(argv[argvindex], "-egi") == 0) {
			doEGI = true;
			argc--;argvindex++;
		}
		else {
			cerr << "Unknown parameter " << argv[argvindex] << endl;
			argc--;argvindex++;
		}
	}
	
	cout << "\nLOADING MODELS...\n\n";

	//Now read in all of the models
	nmodels = atoi(argv[3]);
	if (nmodels == 0) {
		cerr << "ERROR: Must have at least one model per type\n\n";
		exit(0);
	}
	FILE* modeltypesfin = fopen(argv[2], "r");
	if (modeltypesfin == NULL) {
		cerr << "ERROR opening model types file\n";
		exit(0);
	}
	while (!feof(modeltypesfin)) {
		char modeltype[256];
		char fileprefix[300];//Holds the beginning of the file path 
		//without the type (e.g. "models/plane1")
		fscanf(modeltypesfin, "%256s", modeltype);
		for (int i = 0; i < nmodels; i++) {
			sprintf(fileprefix, "%s/%s%i", argv[1], modeltype, i);
			PointCloud pointCloud(fileprefix, modeltype, npoints, resample);
			models.push_back(pointCloud);
		}
		cout << "Finished loading " << modeltype << "(s)\n";
	}
	fclose(modeltypesfin);
	
	cout << "\n\nFINISHED LOADING MODELS.....\n\n";
}


//Compute all of the descriptors that the user requested
void runTests() {
	if (doD2) {
		cout << "\nCompting all " << models.size() << " D2 shape descriptors using " << d2Samples << " random samples...\n";
		for (size_t i = 0; i < models.size(); i++) {
			models[i].getD2(d2Samples);
			cout << (i + 1) << " ";
		}
		cout << "done\n";
	}
	if (doShellPCA) {
		cout << "\nCompting all " << models.size() << " Shells and PCA descriptors...\n";
		cout << "(NOTE: This will also compute all of the shell histograms by default)\n";
		for (size_t i = 0; i < models.size(); i++) {
			models[i].getShellPCA();
			cout << (i + 1) << " ";
		}
		cout << "done\n";
	}
	else if (doShell) {
		cout << "\nCompting all " << models.size() << " shell descriptors...\n";
		for (size_t i = 0; i < models.size(); i++) {
			models[i].getShell();
			cout << (i + 1) << " ";
		}
		cout << "done\n";
	}
	if (doShellSectors || doShellSectorsOverall) {
		cout << "\nCompting all " << models.size() << " shell-sector descriptors...\n";
		for (size_t i = 0; i < models.size(); i++) {
			models[i].getShellSectors();
			cout << (i + 1) << " ";
		}
		cout << "done\n";
	}
	if (doEGI) {
		cout << "\nCompting all " << models.size() << " EGI shape descriptors...\n";
		for (size_t i = 0; i < models.size(); i++) {
			models[i].getEGI();
			cout << (i + 1) << " ";
		}
		cout << "done\n";
	}
}

bool EuclideanDistComparator(PointCloud* elem1, PointCloud* elem2)
{
   return elem1->distance < elem2->distance;
}


vector<double> getPrecisionRecallGraphs(int type) {
	vector<double> PrecisionRecall(nmodels - 1);//There are (nmodels - 1) 
	//other models in a class to recall, so there will be that many elements 
	//on the horizontal axis of the precision-recall graph

	//Run the precision-recall test on every model in the database
	for (size_t basemodel = 0; basemodel < models.size(); basemodel++) {
		//Compute the euclidean distance of the particular descriptor
		//of this model to that of model we're comparing everything to
		vector<PointCloud*> tests;
		for (size_t testmodel = 0; testmodel < models.size(); testmodel++) {
			if (testmodel == basemodel)
				continue;//Don't compare the model against itself
			double distSqr = 0.0;
			if (type == D2) {
				for (int i = 0; i < D2BINS; i++) {
					double diff = (double)models[testmodel].d2[i] - (double)models[basemodel].d2[i];
					distSqr += diff*diff;
				}
			}
			else if (type == SHELL) {
				for (int i = 0; i < SHELLBINS; i++) {
					double diff = (double)models[testmodel].shell[i] - (double)models[basemodel].shell[i];
					distSqr += diff*diff;
				}
			}
			else if (type == SHELLPCA) {
				for (int i = 0; i < SHELLBINS * 3; i++) {
					double diff = models[testmodel].shellPCA[i] - models[basemodel].shellPCA[i];
					distSqr += diff*diff;
				}
			}
			else if (type == SHELLSECTORS) {
				for (int i = 0; i < SHELLBINS; i++) {
					for (size_t j = 0; j < models[testmodel].shellSectors[i].size(); j++) {
						double diff = (double)models[testmodel].shellSectors[i][j];
						diff -= (double)models[basemodel].shellSectors[i][j];
						distSqr += diff*diff;
					}
				}
			}
			else if (type == SHELLSECTORSOVERALL) {
				for (int i = 0; i < SHELLBINS; i++) {
					for (size_t j = 0; j < models[testmodel].shellSectorsOverall[i].size(); j++) {
						double diff = (double)models[testmodel].shellSectorsOverall[i][j];
						diff -= (double)models[basemodel].shellSectorsOverall[i][j];
						distSqr += diff*diff;
					}
				}
			}
			else if (type == EGI) {
				for (int i = 0; i < models[testmodel].EGINormals.size(); i++) {
					double diff = (double)models[testmodel].EGINormals[i];
					diff -= (double)models[basemodel].EGINormals[i];
					distSqr += diff*diff;
				}
			}
			models[testmodel].distance = sqrt(distSqr);
			tests.push_back(&models[testmodel]);
		}
		//Sort the other models from most similar to least similar, based on
		//Euclidean Distance
		sort(tests.begin(), tests.end(), EuclideanDistComparator);

		//Now create a precision-recall graph for this model
		int recall = 0;
		for (size_t i = 0; i < tests.size(); i++) {
			//If this model is of the same class as the model we're comparing everything
			//against, then it's +1 recalled
			if (strcmp(tests[i]->modelClass, models[basemodel].modelClass) == 0) {
				//cout << "(" << recall << ", " << i << ")  ";
				double precision = (double)(recall + 1) / (double)(i + 1);
				PrecisionRecall[recall] += precision;
				recall++;
			}
			if ((size_t)recall >= PrecisionRecall.size())
				break;
		}
		printf(".");
	}
	//Average the precision recall graph
	for (size_t i = 0; i < PrecisionRecall.size(); i++) {
		PrecisionRecall[i] = PrecisionRecall[i] / (double)models.size();
	}
	cout << "done\n\n";
	return PrecisionRecall;
}

void savePrecisionRecallGraphs() {
	if (doD2) {
		printf("Saving D2 precision recall graph as D2PR.txt\n");
		vector<double> PR = getPrecisionRecallGraphs(D2);
		FILE* fout = fopen("D2PR.txt", "w");
		for (size_t i = 0; i < PR.size(); i++) {
			fprintf(fout, "%.3lf\n", PR[i]);
		}
		fflush(fout);
		fclose(fout);
	}
	if (doShell) {
		printf("Saving Shell precision recall graph as ShellPR.txt\n");
		vector<double> PR = getPrecisionRecallGraphs(SHELL);
		FILE* fout = fopen("ShellPR.txt", "w");
		for (size_t i = 0; i < PR.size(); i++) {
			fprintf(fout, "%.3lf\n", PR[i]);
		}
		fflush(fout);
		fclose(fout);
	}
	if (doShellPCA) {
		printf("Saving Shell_PCA precision recall graph as ShellPCAPR.txt\n");
		vector<double> PR = getPrecisionRecallGraphs(SHELLPCA);
		FILE* fout = fopen("ShellPCAPR.txt", "w");
		for (size_t i = 0; i < PR.size(); i++) {
			fprintf(fout, "%.3lf\n", PR[i]);
		}
		fflush(fout);
		fclose(fout);
	}
	if (doShellSectors) {
		printf("Saving Shell_Sectors precision recall graph as ShellSectorsPR.txt\n");
		vector<double> PR = getPrecisionRecallGraphs(SHELLSECTORS);
		FILE* fout = fopen("ShellSectorsPR.txt", "w");
		for (size_t i = 0; i < PR.size(); i++) {
			fprintf(fout, "%.3lf\n", PR[i]);
		}
		fflush(fout);
		fclose(fout);
	}
	if (doShellSectorsOverall) {
		printf("Saving Shell_Sectors overall precision recall graph as ShellSectorsOverallPR.txt\n");
		vector<double> PR = getPrecisionRecallGraphs(SHELLSECTORSOVERALL);
		FILE* fout = fopen("ShellSectorsOverallPR.txt", "w");
		for (size_t i = 0; i < PR.size(); i++) {
			fprintf(fout, "%.3lf\n", PR[i]);
		}
		fflush(fout);
		fclose(fout);
	}
	if (doEGI) {
		printf("Saving EGI precision recall graph as EGIPR.txt\n");
		vector<double> PR = getPrecisionRecallGraphs(EGI);
		FILE* fout = fopen("EGIPR.txt", "w");
		for (size_t i = 0; i < PR.size(); i++) {
			fprintf(fout, "%.3lf\n", PR[i]);
		}
		fflush(fout);
		fclose(fout);
	}
}

int main(int argc, char** argv) {
	parseArgs(argc, argv);
	runTests();
	cout << "\n\nCALCULATING PRECISION RECALL GRAPHS ...\n\n";
	savePrecisionRecallGraphs();
	return 0;
}