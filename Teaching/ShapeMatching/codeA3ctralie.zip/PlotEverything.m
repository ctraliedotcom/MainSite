function PlotEverything(titlestring)
D2 = [load('Debug/D2PR.txt')];
Shell = [load('Debug/ShellPR.txt')];
ShellPCA = [load('Debug/ShellPCAPR.txt')];
ShellSectors = [load('Debug/ShellSectorsPR.txt')];
ShellSectorsOverall = [load('Debug/ShellSectorsOverallPR.txt')];
EGI = [load('Debug/EGIPR.txt')];

Recall = 1:9;
Recall = Recall / 9;

plot(Recall, D2, 'red');
hold;
plot(Recall, Shell, 'green');
plot(Recall, ShellPCA, 'blue');
plot(Recall, ShellSectors, 'yellow');
plot(Recall, ShellSectorsOverall, 'black');
plot(Recall, EGI, 'cyan');

legend('d2', 'shell', 'shell-PCA', 'shell-Sectors', 'shell-Sectors Overall', 'EGI');
xlabel('recall');
ylabel('precision');
title(titlestring);

end

