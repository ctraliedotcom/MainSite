/*Programmer: Chris Tralie
*Purpose: To create an organized class to store a point cloud,
*and to create member functions that can calculate descriptors
*of this point cloud*/

#ifndef POINTCLOUD_H
#define POINTCLOUD_H

#include <iostream>
#include <fstream>
#include <vector>

#include <R3.h>

#define D2BINS 100
#define MAXD2 3.0
#define SHELLBINS 10
#define MAXSHELL 3.0

using namespace std;


class PointCloud {
public:
	PointCloud(char* fileprefix, char* mclass, int npoints, bool resample);
	//Member functions that can calculate the descriptors
	void ResamplePoints(char* fileprefix, int nsamples);
	void getD2(int nsamples);
	void getShell();
	void getShellPCA();
	void getShellSectors();
	void getEGI();

	char modelClass[256];//The class of models this belogs to (e.g. "plane")
	char fullname[256];//can be used for debugging
	vector<R3Point> points;
	vector<R3Vector> normals;
	//"Axis-aligned" points and normals (normalized for rotation)
	vector<R3Point> aapoints;
	vector<R3Vector> aanormals;
	R3Point CM;//Center of mass

	//Store the different descriptors here
	long int d2[D2BINS];
	long int shell[SHELLBINS];
	double shellPCA[SHELLBINS * 3];
	vector<int> shellSectors[SHELLBINS];
	vector<int> shellSectorsOverall[SHELLBINS];//Sectors are sorted
	//over all of the shell
	vector<int> EGINormals;

	double distance;//The distance of some descriptor here
	//from the same descriptor in another model (precomputed to
	//speed up the sorting algorithms)
};

struct SectorCount {
	int sector;
	int count;
};

#endif