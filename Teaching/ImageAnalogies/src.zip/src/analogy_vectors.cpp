// COS 526, Spring 2010, Assignment 1



// Include files

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <vector>
#include <set>
#include <math.h>
#include <float.h>
#include "R2Pixel.h"
#include "R2Image.h"

using namespace std;

typedef back_insert_iterator<vector<double>> FeatureConcatnator;

//Struct for holding pixel coordinates
class Coord {
public:
	int x, y;
	Coord(int x, int y){this->x = x;this->y = y;}
	Coord() {x = -1; y = -1;}//Default constructor is (-1, -1) so that
	//"s buffer" can tell if a pixel has been assigned yet in Bp
	double Dist(Coord other) {
		//Use this for debugging to see how far corresponding pixels are apart
		//TODO: Check coherence search with this
		double dx = x - other.x;
		double dy = y - other.y;
		return sqrt(dx*dx + dy*dy);
	}
};

//Other two are too blurry
//const double gaussianSIG2[11] = {0.0088, 0.0271, 0.0651, 0.1216, 0.1770, 0.2006, 0.1770, 0.1216, 0.0651, 0.0271, 0.0088};
//const double gaussianSIG1_5[11] = {0.0010, 0.0076, 0.0360, 0.1094, 0.2130, 0.2660, 0.2130, 0.1094, 0.0360, 0.0076, 0.0010};
//const double gaussian[9] = {0.0001, 0.0044, 0.0540, 0.2420, 0.3989, 0.2420, 0.0540, 0.0044, 0.0001};
const double gaussian[7] = {0.0001, 0.0103, 0.2075, 0.5641, 0.2075, 0.0103, 0.0001};
const int smallestPyramid = 50;
const int gaussianWidth = 3;
class GaussianPyramid {
public:
	int L;
	vector<R2Image*> images;

	GaussianPyramid(int levels) {
		L = levels;
	}
	GaussianPyramid(R2Image* im) {
		L = 1;
		R2Image* thisImage = im;
		while(true) {
			printf("Constructing level %i\n", L);
			//Create images from large to small then reverse order
			images.push_back(thisImage);
			int width = thisImage->Width(), height = thisImage->Height();
			if (width < smallestPyramid || height < smallestPyramid)
				break;
			R2Image* temp = new R2Image(width, height);
			//Blur image with the 11x11 gaussian kernel
			for (int y = 0; y < height; y++) {
				for (int x = 0; x < width; x++) {
					//Blur in x direction first
					R2Pixel P = R2black_pixel;
					for (int dx = -gaussianWidth; dx <= gaussianWidth; dx++) {
						int newx = x + dx;
						if (newx >= width) newx = 2*width-newx-1;//Reflect across boundaries
						if (newx < 0) newx = -newx;
						P = P + gaussian[dx+gaussianWidth]*thisImage->Pixel(newx, y);
					}
					temp->SetPixel(x, y, P);
				}
			}
			R2Image* temp2 = new R2Image(width, height);
			for (int y = 0; y < height; y++) {
				for (int x = 0; x < width; x++) {
					R2Pixel P = R2black_pixel;
					//Now blur in y direction (separable filter)
					for (int dy = -gaussianWidth; dy <= gaussianWidth; dy++) {
						int newy = y + dy;
						if (newy >= height) newy = 2*height-newy-1;
						if (newy < 0) newy = -newy;
						P = P + gaussian[dy+gaussianWidth]*temp->Pixel(x, newy);
					}
					temp2->SetPixel(x, y, P);
				}
			}
			delete temp;
			//Now that it's blurred, downsample
			R2Image* newImage = new R2Image(width/2, height/2);
			for (int y = 0; y < height; y+=2) {
				for (int x = 0; x < width; x+=2) {
					newImage->SetPixel(x/2, y/2, temp2->Pixel(x, y));
				}
			}
			delete temp2;
			thisImage = newImage;
			L++;
		}
		vector<R2Image*> actualOrder;
		//Reverse the order so the smallest images is at index 0
		while (images.size() > 0) {
			actualOrder.push_back(images[images.size()-1]);
			images.pop_back();
		}
		images = actualOrder;
	}

	//For debugging
	void writeImages(string prefix) {
		char filename[1024];
		for (size_t i = 0; i < images.size(); i++) {
			sprintf(filename, "%s%i.bmp", prefix.data(), i);
			images[i]->WriteBMP(filename);
		}
	}

	R2Image* getImage(int level) {
		if (level < images.size() && level >= 0)
			return images[level];
		else {
			//fprintf(stderr, "ERROR: Image %i requested from pyramid with %i levels\n", level, images.size());
			return NULL;
		}
	}

	~GaussianPyramid() {
		//De-allocate all images
		for (size_t i = 0; i < images.size(); i++) {
			delete images[i];
		}
	}
};

// Base program arguments
static char *A_filename = NULL;
static char *Ap_filename = NULL;
static char *B_filename = NULL;
static char *Bp_filename = NULL;
static R2Pixel mask_color = R2blue_pixel;
static int neighborhood_size = 5;

//Other arguments
static bool ANN = true;
static bool luminanceRemapping = false;
static bool constrainedSynthesis = false;
static bool useAColors = false;
static int L = 1;//Number of multires levels
static double sigL = 1.0, meanAL = 0.0, meanBL = 0.0;//Luminance remapping parameters
static double Kappa = 0;//Coherence coefficient

//Which features to use
static bool spatialNeighborhood = true;//Spatial neighborhood with luminance
static bool steerableFilters;

//Size of features (these need to be odd)
static int spatialKFine = 5;//Fine level
static int spatialKCoarse = 3;//Coarse level


static set<int> pixelLocs;//The unique locations of the pixels that are drawn from A

static R2Image *
ReadImage(const char *filename) 
{
  // Allocate input_image
  R2Image *image = new R2Image();
  if (!image) {
    fprintf(stderr, "Unable to allocate image\n");
    return NULL;
  }

  // Read input image
  if (!image->Read(filename)) {
    fprintf(stderr, "Unable to read image from %s\n", filename);
    return NULL;
  }

  // Return image
  return image;
}

static double* vector2Double(vector<double>* vec) {
	int size = vec->size();
	double* ret = new double(size);
	for (int i = 0; i < size; i++) {
		ret[i] = (*vec)[i];
	}
	return ret;
}

//Get the features for the image im at position (x,y)
//coarse indicates whether a fine or coarse window is being taken
//AImage indicates whether it's from the pair (A, A') or the pair (B, B') (only important for luminance remapping)
//causal tells whether a square KxK neighborhood can be taken or if a causal L-Shaped neighborhood is taken
static vector<double> getFeature(R2Image* im, int x, int y, bool coarse, bool AImage, bool causal) {
	vector<double> feature;
	int width = im->Width(), height = im->Height();
	if (spatialNeighborhood) {
		int K = coarse?spatialKCoarse:spatialKFine;
		//First append KxK luminance neighborhood in original im image
		for (int dy = -K/2; ((dy <= 0)&&causal) || ((dy <= K/2)&&!causal); dy++) {
			for (int dx = -K/2; dx <= K/2; dx++) {
				if (causal && dy == 0 && dx == 0)
					break;//Don't use pixels that scanline hasn't reached yet if neighborhood is causal
				int thisx = x + dx;
				int thisy = y + dy;
				//Reflect image around edges
				if (thisx < 0) thisx = -thisx;
				if (thisy < 0) thisy = -thisy;
				if (thisx >= width) thisx = 2*width - thisx - 1;
				if (thisy >= height) thisy = 2*width - thisy - 1;
				//Otherwise, if entire patch is within range, use the actual luminance value
				double lum = im->Pixel(thisx, thisy).Luminance();
				if (AImage && luminanceRemapping)
					lum = sigL*(lum - meanAL) + meanBL;
				feature.push_back(lum);
			}
		}
	}//End of spatial neighborhood luminance feature

	if (steerableFilters) {
		
	}
	return feature;
}


static vector<double>* precomputeFeatures(R2Image* im, bool coarse, bool AImage, bool causal) {
	int NPixels = im->NPixels();
	int width = im->Width(), height = im->Height();
	vector<double>* ret = new vector<double>[NPixels];
	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++) {
			ret[y*width + x] = getFeature(im, x, y, coarse, AImage, causal);
		}
	}
	return ret;
}

double getL2Dist(vector<double>* F1, vector<double>* F2) {
	if (F1->size() != F2->size())
		fprintf(stderr, "%i  %i\n\n", F1->size(), F2->size());
	assert(F1->size() == F2->size());
	//Now compare features and normalize based on number of components compared
	int size = F1->size();
	int num = 0;//Number of components compared
	double L2Dist = 0.0;
	for (int j = 0; j < size; j++) {
		double f1_j = (*F1)[j], f2_j = (*F2)[j];
		//if (f1_j == -1 || f2_j == -1)
		//	continue;//If the pixel isn't supposed to be included, don't compare it
		double dist = f1_j - f2_j;
		L2Dist += dist*dist;
		num++;
	}
	if (num > 0)
		L2Dist /= (double)num;
	else
		L2Dist = FLT_MAX;
	return L2Dist;
}

//Exhaustive nearest neighbor search: compare feature vector from B
//to all of the A->A' examples and return the distance of the one
//with the smallest L2Norm, and implicitly return that location
//through the by-reference "bestCoord" parameter
static double exhaustiveNN(vector<double>* AllAFeatures, const R2Image* A, int NFeatures, 
						   vector<double>* FullBFeature, Coord& bestCoord) {
	double minNorm = FLT_MAX;
	int width = A->Width(), height = A->Height();
	for (int i = 0; i < NFeatures; i++) {
		double L2Dist = getL2Dist(&AllAFeatures[i], FullBFeature);
		if (L2Dist <= minNorm) {
			minNorm = L2Dist;
			bestCoord.x = i % width;
			bestCoord.y = i / width;
		}
	}
	return minNorm;
}

//Return the closest "coherent" pixel location
double getBestCoherent(const R2Image* A, const R2Image* B, vector<double>* AllAFeatures, 
					   vector<double>* FullBFeature, Coord* s, Coord q, Coord& bestCoord) {
	if (Kappa == 0.0) //If no coherence is being used, don't bother looking
		return FLT_MAX;
	int AWidth = A->Width(), AHeight = A->Height();
	int BWidth = B->Width(), BHeight = B->Height();
	double minNorm = FLT_MAX;
	//For each pixel r in the neighborhood of q
	//Use the fine spatial neighborhood resolution since coherence is only done
	//at the fine level
	int bound = spatialKFine / 2;
	for (int dx = -bound; dx <= bound; dx++) {
		for (int dy = -bound; dy <= bound; dy++) {
			if (dx == 0 && dy == 0)
				continue;
			//Take the pixel that r was drawn from in A and go to the relative position
			//q would have been at if the entire patch had been drawn (s(r) + q-r)
			int rx = q.x + dx, ry = q.y + dy;
			if (rx < 0 || rx >= BWidth || ry < 0 || ry >= BHeight)
				continue;//Don't go out of bounds
			Coord Pr = s[rx + ry*BWidth];//The pixel P that was sampled at location r
			if (Pr.x == -1 && Pr.y == -1) {
				//The pixel hasn't been drawn yet at that location
				continue;
			}
			int x = Pr.x + q.x - rx;//Go to relative position of q
			int y = Pr.y + q.y - ry;
			if (x < 0 || x >= AWidth || y < 0 || y >= AHeight)
				continue;///Don't go out of bounds
			double L2Dist = getL2Dist(&AllAFeatures[x + y*AWidth], FullBFeature);
			if (L2Dist <= minNorm) {
				minNorm = L2Dist;
				bestCoord = Coord(x, y);
			}
		}
	}
	return minNorm;
}

//AFeatures: List of all A features concatnated with A' features
//BFeatures: List of all B features (not yet concatnated with B' features)
//s: For coherence search
//q: The coordinate in the b image where we're trying to find the best pixel
//l: the current multires level
static Coord findBestMatch(const R2Image* A, const R2Image* B, R2Image* Bp, vector<double>* AllAFeatures, 
						   vector<double>* BFeatures, Coord* s, Coord q, int l) {
	int x = q.x;
	int y = q.y;
	int index = x + y*B->Width();

	vector<double> BpFeature = getFeature(Bp, x, y, false, false, true);
	vector<double> FullBFeature;
	FeatureConcatnator FC(FullBFeature);
	copy(BFeatures[index].begin(), BFeatures[index].end(), FC);
	copy(BpFeature.begin(), BpFeature.end(), FC);
	Coord bestApproxCoord, bestCoherentCoord;

	double dApp = exhaustiveNN(AllAFeatures, A, A->NPixels(), &FullBFeature, bestApproxCoord);
	double dCoh = getBestCoherent(A, B, AllAFeatures, &FullBFeature, s, q, bestCoherentCoord);
	if (dCoh <= dApp*(1 + pow(2.0, (double)(l-L))*Kappa))
		return bestCoherentCoord;
	return bestApproxCoord;
}

static void calculateLuminanceRemappingParams(const R2Image* A, const R2Image* B) {
	//static double sigL = 1.0, meanAL = 0.0, meanBL = 0.0;//Luminance remapping parameters
	meanAL = 0.0;
	meanBL = 0.0;
	double sigAL = 0.0;//Standard deviation in luminance
	double sigBL = 0.0;
	for (int x = 0; x < A->Width(); x++) {
		for (int y = 0; y < A->Height(); y++) {
			meanAL += A->Pixel(x, y).Luminance();
		}
	}
	meanAL /= (double)A->NPixels();
	for (int x = 0; x < A->Width(); x++) {
		for (int y = 0; y < A->Height(); y++) {
			double diff = A->Pixel(x,y).Luminance() - meanAL;
			sigAL += diff*diff;
		}
	}
	sigAL = sqrt(sigAL / (double)A->NPixels());
	for (int x = 0; x < B->Width(); x++) {
		for (int y = 0; y < B->Height(); y++) {
			meanBL += B->Pixel(x, y).Luminance();
		}
	}
	meanBL /= (double)B->NPixels();
	for (int x = 0; x < B->Width(); x++) {
		for (int y = 0; y < B->Height(); y++) {
			double diff = B->Pixel(x,y).Luminance() - meanBL;
			sigBL += diff*diff;
		}
	}
	sigBL = sqrt(sigBL / (double)B->NPixels());
	if (sigAL <= 0)	sigL = 1.0;//Prevent divide by zero
	else sigL = sigBL / sigAL;
}

static void printFeature(vector<double> feature) {
	printf("[");
	for (size_t j = 0; j < feature.size(); j++) {
		printf("%.3lf");
		if (j < feature.size() - 1)
			printf(", ");
	}
	printf("]\n");
}

static double getFeatureMag(vector<double> feature) {
	if (feature.size() == 0)
		return 0.0;
	double mag = 0.0;
	for (size_t i = 0; i < feature.size(); i++)
		mag += feature[i]*feature[i];
	return sqrt(mag);
}

static R2Image *
CreateAnalogyImage(const R2Image *AImage, const R2Image *ApImage, const R2Image *BImage)
{
	// Allocate Bp image
	R2Image *Bp = new R2Image(B->Width(), B->Height());
	if (!Bp) {
	fprintf(stderr, "Unable to allocate output_image\n");
	exit(-1);
	}

	if(luminanceRemapping)
		calculateLuminanceRemappingParams(A, B);

	GaussianPyramid APyramid((R2Image*)AImage);
	GaussianPyramid ApPyramid((R2Image*)ApImage);
	GaussianPyramid BPyramid((R2Image*)BImage);
	GaussainPyramid BpPyramid(BPyramid.L);//Create an empty Gaussian Pyramid for the Bp
	//image which will be synthesized

	R2Image *A, *Ap, *B, *Bp;
	R2Image *Al, *Apl, *Bl, *Bpl;//Images one level below
	//All of the features to be computed each round
	vector<double> *AlFeatures, *AplFeatures, *AFeatures, *ApFeatures;
	vector<double> *BlFeatures, *BplFeatures, *BFeatures;

	vector<double>* lastAllAFeatures = NULL;
	vector<double>* lastBFeatures
	for (int level = 0; level < APyramid.L; level++) {
		A = APyramid.getImage(level);
		Ap = ApPyramid.getImage(level);
		B = BPyramid.getImage(level);
		Al = APyramid.getImage(level-1);
		Apl = ApPyramid.getImage(level-1);
		Bl = BPyramid.getImage(level-1);
		Bpl = BpPyramid.getImage(level-1);

		int BWidth = B->Width(), BHeight = B->Height();
		//Allocate the new image Bp
		Bp = new R2Image(BWidth, BHeight);
		BpPyramid.images.push_back(Bp);

		//Allocate space for the "s" buffer, which stores which pixel matched
		//best from A'
		Coord* s = new Coord[Bp->NPixels()];

		printf("Finished pre-computing features\n\n");

		if (!constrainedSynthesis) {
			//Look at the pixels in scan-line order
			for (int y = 0; y < BpHeight; y++) {
				printf("%i  ", y);
				for (int x = 0; x < BpWidth; x++) {
					Coord q = Coord(x, y);
					Coord p = findBestMatch(A, B, Bp, AllAFeatures, BFeatures, s, q, 1);
					if (!useAColors) {
						//Set pixel in Bp to be the luminance of the pixel in Ap but keep colors in B 
						R2Pixel newPixel(B->Pixel(x, y));
						newPixel.SetYIQ(Ap->Pixel(p.x, p.y).Y(), newPixel.I(), newPixel.Q());
						Bp->SetPixel(x, y, newPixel);//B'l(q) = A'l(p)
						//Bp->SetPixel(x, y, B->Pixel(p.x, p.y));
					}
					else {
						//Copy the pixel directly over from Ap to Bp (useful for cases like emboss)
						Bp->SetPixel(x, y, Ap->Pixel(p.x, p.y));
					}
					pixelLocs.insert(p.x + p.y*A->Width());
					s[y*BpWidth + x] = p;//sl(q) <--- p

					//printf("%.3lf\n", q.Dist(p));
				}
			}
		}
		else {
			//Find pixels in a mask (color black) and fill them in around the boundary
		}
		delete[] s;
		
		printf("\n\n%i out of %i unique pixels drawn from A\n\n", pixelLocs.size(), A->NPixels());
		pixelLocs.clear();
	}//End Gaussian Pyramid loop

	// Return Bp image
	return Bp;
}



static int 
ParseArgs(int argc, char **argv)
{
  // Parse program arguments 
  argv++, argc--; 
  while (argc > 0) {
    if ((*argv)[0] == '-') {
      if (!strcmp(*argv, "-neighborhood_size")) { argv++; argc--; neighborhood_size = atoi(*argv); }
      else if (!strcmp(*argv, "-mask_color")) { mask_color.Reset(atof(argv[1]),atof(argv[2]),atof(argv[3]),1); argv+=3; argc-=3; }
	  else if (!strcmp(*argv, "-useAColors")) {useAColors = true;}
	  else if (!strcmp(*argv, "-luminanceRemapping")) {luminanceRemapping = true;}
	  else if (!strcmp(*argv, "-kappa")) { argv++; argc--; Kappa = atof(*argv); }
	  else { fprintf(stderr, "Invalid option: %s\n", *argv); return 0; }
    }
    else {
      if (!A_filename) A_filename = *argv;
      else if (!Ap_filename) Ap_filename = *argv;
      else if (!B_filename) B_filename = *argv;
      else if (!Bp_filename) Bp_filename = *argv;
      else { fprintf(stderr, "Invalid option: %s\n", *argv); return 0; }
    }
    argv++, argc--; 
  }

  // Check program arguments
  if (!A_filename || !Ap_filename || !B_filename || !Bp_filename) {
    fprintf(stderr, "Usage: analogy A A\' B B\'[-mask_color r g b] [-neighborhood_size npixels]\n");
    return 0;
  }

  // Return success
  return 1;
}



int 
main(int argc, char **argv)
{
	// Parse program arguments
	if (!ParseArgs(argc, argv)) exit(-1);

	// Read input images
	R2Image *A = ReadImage(A_filename);
	if (!A) exit(-1);
	R2Image *Ap = ReadImage(Ap_filename);
	if (!Ap) exit(-1);
	R2Image *B = ReadImage(B_filename);
	if (!B) exit(-1);

	// Create output image
	R2Image *Bp = CreateAnalogyImage(A, Ap, B);
	if (!Bp) exit(-1);

	// Write output image
	if (!Bp->Write(Bp_filename)) exit(-1);

	/*R2Image* A = ReadImage(argv[1]);
	GaussianPyramid pyr(A);
	printf("Finished contructing gaussian pyramid\n");
	pyr.writeImages("pyramid\\level");*/

	// Return success
	return 0;
}