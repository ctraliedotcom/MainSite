// COS 526, Spring 2010, Assignment 1



// Include files

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <vector>
#include <set>
#include <math.h>
#include <float.h>
#include <ctime>
#include "ANN/ANN.h"
#include "R2Pixel.h"
#include "R2Image.h"

using namespace std;


// Base program arguments
static char *A_filename = NULL;
static char *Ap_filename = NULL;
static char *B_filename = NULL;
static char *Bp_filename = NULL;
static R2Pixel mask_color = R2blue_pixel;

//Other arguments
static bool ANN = true;
static bool luminanceRemapping = false;
static bool holeFilling = false;
static bool useAColors = false;
static bool noGaussianLuminance = false;
static int L = 1;//Number of multires levels
static double sigL = 1.0, meanAL = 0.0, meanBL = 0.0;//Luminance remapping parameters
static double Kappa = 0;//Coherence coefficient
static bool outputPyramid = false;
static char* pyramidDir;
static double ANNEps = 1.0;
static bool verbose = false;

//Which features to use
static bool spatialNeighborhood = true;//Spatial neighborhood with luminance
static bool steerableFilters = false;

//Size of features (these need to be odd)
static int spatialKFine = 5;//Fine level
static int spatialKCoarse = 3;//Coarse level


static set<int> pixelLocs;//The unique locations of the pixels that are drawn from A


//Struct for holding pixel coordinates
class Coord {
public:
	int x, y;
	Coord(int x, int y){this->x = x;this->y = y;}
	Coord() {x = -1; y = -1;}//Default constructor is (-1, -1) so that
	//"s buffer" can tell if a pixel has been assigned yet in Bp
	double Dist(Coord other) {
		//Use this for debugging to see how far corresponding pixels are apart
		//TODO: Check coherence search with this
		double dx = x - other.x;
		double dy = y - other.y;
		return sqrt(dx*dx + dy*dy);
	}
};

//The Gaussian is separable so only store a 1D version
//Other two are too blurry
//const double gaussianSIG2[11] = {0.0088, 0.0271, 0.0651, 0.1216, 0.1770, 0.2006, 0.1770, 0.1216, 0.0651, 0.0271, 0.0088};
//const double gaussianSIG1_5[11] = {0.0010, 0.0076, 0.0360, 0.1094, 0.2130, 0.2660, 0.2130, 0.1094, 0.0360, 0.0076, 0.0010};
//const double gaussian[9] = {0.0001, 0.0044, 0.0540, 0.2420, 0.3989, 0.2420, 0.0540, 0.0044, 0.0001};
const double gaussian[7] = {0.0001, 0.0103, 0.2075, 0.5641, 0.2075, 0.0103, 0.0001};
const int smallestPyramid = 50;
const int gaussianWidth = 3;
class GaussianPyramid {
public:
	int L;
	R2Image** images;

	GaussianPyramid(int levels) {
		//Make an object but don't put anything in the images array yet 
		L = levels;
		images = new R2Image*[L];
		for (int i = 0; i < L; i++)
			images[i] = NULL;
	}

	GaussianPyramid(R2Image* im, int levels) {
		L = levels;
		images = new R2Image*[L];
		images[L-1] = im;
		R2Image* temp = new R2Image(im->Width(), im->Height());
		R2Image* temp2 = new R2Image(im->Width(), im->Height());
		for (int level = L-2; level >= 0; level--) {
			int width = images[level+1]->Width();
			int height = images[level+1]->Height();
			for (int x = 0; x < width; x++) {
				for (int y = 0; y < height; y++) {
					//Blend along x first
					temp->Pixel(x,y) = R2black_pixel;//Reset pixel from last time
					for (int dx = -gaussianWidth; dx <= gaussianWidth; dx++) {
						int xcoord = x+dx;
						if (xcoord < 0) xcoord = -xcoord;
						if (xcoord >= width) xcoord = 2*width-1-xcoord;
						temp->Pixel(x, y) += gaussian[gaussianWidth+dx]*images[level+1]->Pixel(xcoord, y);
					}
				}
			}
			for (int x = 0; x < width; x++) {
				for (int y = 0; y < height; y++) {
					//Now blend along y
					temp2->Pixel(x, y) = R2black_pixel;
					for (int dy = -gaussianWidth; dy <= gaussianWidth; dy++) {
						int ycoord = y + dy;
						if (ycoord < 0) ycoord = -ycoord;
						if (ycoord >= height) ycoord = 2*height-1-ycoord;
						temp2->Pixel(x, y) += gaussian[gaussianWidth+dy]*images[level+1]->Pixel(x, ycoord);
					}
				}
			}
			images[level] = new R2Image(width/2, height/2);
			for (int x = 0; x < width/2; x++) {
				for (int y = 0; y < height/2; y++) {
					images[level]->Pixel(x, y) = temp2->Pixel(x*2, y*2);
				}
			}
		}
		delete temp;
		delete temp2;
	}

	//For debugging, output the entire image pyramid to files
	void writeImages(string prefix) {
		char filename[1024];
		for (int i = 0; i < L; i++) {
			sprintf(filename, "%s%i.bmp", prefix.data(), i);
			if (images[i] == NULL)
				fprintf(stderr, "ERROR: Image at level %i has not been initialized\n", i);
			else
				images[i]->WriteBMP(filename);
		}
	}

	R2Image* getImage(int level) {
		if (level < L && level >= 0)
			return images[level];
		else {
			//fprintf(stderr, "ERROR: Image %i requested from pyramid with %i levels\n", level, images.size());
			return NULL;
		}
	}

	~GaussianPyramid() {
		for (int i = 0; i < L; i++) {
			if (images[i] != NULL)
				delete images[i];
		}
		delete[] images;
	}
};

static R2Image *
ReadImage(const char *filename) 
{
  // Allocate input_image
  R2Image *image = new R2Image();
  if (!image) {
    fprintf(stderr, "Unable to allocate image\n");
    return NULL;
  }

  // Read input image
  if (!image->Read(filename)) {
    fprintf(stderr, "Unable to read image from %s\n", filename);
    return NULL;
  }

  // Return image
  return image;
}

static bool isMaskColor(R2Pixel pixel) {
	return (pixel == mask_color);
}

static void deallocateFeatureArray(double** arr, int NFeatures) {
	for (int i = 0; i < NFeatures; i++) {
		delete[] arr[i];
	}
	delete[] arr;
}

//NOTE: This function assumes that there is enough space in "parentFeature" to accomadate "newFeature"
//at the end...
static void appendFeature(double* parentFeature, int start, double* newFeature, int newFeatureSize) {
	for (int i = 0; i < newFeatureSize; i++) {
		parentFeature[start+i] = newFeature[i];
	}
}

//Get the features for the image im at position (x,y)
//coarse indicates whether a fine or coarse window is being taken
//AImage indicates whether it's from the pair (A, A') or the pair (B, B') (only important for luminance remapping)
//causal tells whether a square KxK neighborhood can be taken or if a causal L-Shaped neighborhood is taken
//Store the size of the feature in the "size" by-reference parameter
static double* getFeature(R2Image* im, int x, int y, bool coarse, bool AImage, bool causal, int* size) {
	vector<double> feature;
	int width = im->Width(), height = im->Height();
	int gain = spatialKFine*spatialKFine / (spatialKCoarse*spatialKCoarse);
	int K = coarse?spatialKCoarse:spatialKFine;
	if (spatialNeighborhood) {
		//First append KxK luminance neighborhood in original im image
		for (int dy = -K/2; ((dy <= 0)&&causal) || ((dy <= K/2)&&!causal); dy++) {
			for (int dx = -K/2; dx <= K/2; dx++) {
				if (causal && dy == 0 && dx == 0)
					break;//Don't use pixels that scanline hasn't reached yet if neighborhood is causal
				int thisx = x + dx;
				int thisy = y + dy;
				//Reflect image around edges
				if (thisx < 0) thisx = -thisx;
				if (thisy < 0) thisy = -thisy;
				if (thisx >= width) thisx = 2*width - thisx - 1;
				if (thisy >= height) thisy = 2*height - thisy - 1;
				//Otherwise, if entire patch is within range, use the actual luminance value
				double lum = im->Pixel(thisx, thisy).Luminance();
				if (AImage && luminanceRemapping)
					lum = sigL*(lum - meanAL) + meanBL;
				if (!noGaussianLuminance) {
					//Scale features further away from center down to de-emphasize them
					lum *= 0.5*pow(2.0, -8*(dx*dx+dy*dy)/(K*K));
				}
				if (coarse) {
					//Scale feature so that it has the same weight as level above it (Section 3.2)
					lum *= gain;
				}
				if (holeFilling && isMaskColor(im->Pixel(thisx, thisy)))
					feature.push_back(FLT_MAX);//Ensure that neighborhoods with blue pixels never get used
				else
					feature.push_back(lum);
			}
		}
	}//End of spatial neighborhood luminance feature

	if (steerableFilters) {
		double Fx = 0.0;
		double Fy = 0.0;
		for (int dy = -K/2; ((dy <= 0)&&causal) || ((dy <= K/2)&&!causal); dy++) {
			for (int dx = -K/2; dx <= K/2; dx++) {
				if (causal && dy == 0 && dx == 0)
					break;//Don't use pixels that scanline hasn't reached yet if neighborhood is causal
				int thisx = x + dx;
				int thisy = y + dy;
				//Reflect image around edges
				if (thisx < 0) thisx = -thisx;
				if (thisy < 0) thisy = -thisy;
				if (thisx >= width) thisx = 2*width - thisx - 1;
				if (thisy >= height) thisy = 2*height - thisy - 1;
				//Otherwise, if entire patch is within range, use the actual luminance valueum
				double lum = im->Pixel(thisx, thisy).Luminance();
				double expGain = pow(2.0, -(dx*dx+dy*dy));
				if (!coarse)
					expGain = pow(2.0, -0.3*(dx*dx+dy*dy));
				Fx += 2*lum*dx*expGain;
				Fy += 2*lum*dy*expGain;
			}
		}
		feature.push_back(Fx);
		feature.push_back(Fy);
	}

	//Copy all elements in vector back over to a double array
	double* ret = new double[feature.size()];
	(*size) = feature.size();
	for (int i = 0; i < (*size); i++) {
		ret[i] = feature[i];
	}
	return ret;
}


static double** computeAllFeatures(R2Image* im, bool coarse, bool AImage, bool causal, int* size) {
	int NPixels = im->NPixels();
	int width = im->Width(), height = im->Height();
	double** ret = new double*[NPixels];
	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++) {
			int thisSize;
			ret[y*width + x] = getFeature(im, x, y, coarse, AImage, causal, &thisSize);
			*size = thisSize;
		}
	}
	return ret;
}

/*double getL2Dist(double* F1, double* F2, int size) {
	//Now compare features and normalize based on number of components compared
	int num = 0;//Number of components compared
	double L2Dist = 0.0;
	for (int j = 0; j < size; j++) {
		double dist = F1[j] - F2[j];
		L2Dist += dist*dist;
		num++;
	}
	if (num > 0)
		L2Dist /= (double)num;
	else
		L2Dist = FLT_MAX;
	return L2Dist;
}*/

double getL2Dist(double* F1, double* F2, int size) {
	double L2Dist = 0.0;
	for (int j = 0; j < size; j++) {
		double dist = F1[j] - F2[j];
		L2Dist += dist*dist;
	}
	return sqrt(L2Dist);
}

//Exhaustive nearest neighbor search: compare feature vector from B
//to all of the A->A' examples and return the distance of the one
//with the smallest L2Norm, and implicitly return that location
//through the by-reference "bestCoord" parameter
static double bruteForceNN(double** AFeatures, const R2Image* A, double* BFeature, 
						   int size, Coord& bestCoord) {
	double minNorm = FLT_MAX;
	int width = A->Width();
	int NFeatures = A->NPixels();
	for (int i = 0; i < NFeatures; i++) {
		double L2Dist = getL2Dist(AFeatures[i], BFeature, size);
		if (L2Dist <= minNorm) {
			minNorm = L2Dist;
			bestCoord.x = i % width;
			bestCoord.y = i / width;
		}
	}
	return minNorm;
}

//Return the closest "coherent" pixel location
double getBestCoherent(const R2Image* A, const R2Image* B, double** AFeatures, 
					   double* BFeature, int size, Coord* s, Coord q, Coord& bestCoord) {
	if (Kappa == 0.0) //If no coherence is being used, don't bother looking
		return FLT_MAX;
	int AWidth = A->Width(), AHeight = A->Height();
	int BWidth = B->Width(), BHeight = B->Height();
	double minNorm = FLT_MAX;
	//For each pixel r in the neighborhood of q
	//Use the fine spatial neighborhood resolution since coherence is only done
	//at the fine level
	int bound = spatialKFine / 2;
	int comparisons = 0;
	for (int dx = -bound; dx <= bound; dx++) {
		for (int dy = -bound; dy <= bound; dy++) {
			if (dx == 0 && dy == 0)
				continue;
			//Take the pixel that r was drawn from in A and go to the relative position
			//q would have been at if the entire patch had been drawn (s(r) + q-r)
			int rx = q.x + dx, ry = q.y + dy;
			if (rx < 0 || rx >= BWidth || ry < 0 || ry >= BHeight)
				continue;//Don't go out of bounds
			Coord Pr = s[rx + ry*BWidth];//The pixel P that was sampled at location r
			if (Pr.x == -1 && Pr.y == -1) {
				//The pixel hasn't been drawn yet at that location
				continue;
			}
			int x = Pr.x + q.x - rx;//Go to relative position of q
			int y = Pr.y + q.y - ry;
			if (x < 0 || x >= AWidth || y < 0 || y >= AHeight)
				continue;///Don't go out of bounds
			double L2Dist = getL2Dist(AFeatures[x + y*AWidth], BFeature, size);
			comparisons++;
			if (L2Dist <= minNorm) {
				minNorm = L2Dist;
				bestCoord = Coord(x, y);
			}
		}
	}
	return minNorm;
}

//AFeatures: List of all A features concatnated with A' features
//BFeature: A B Feature (not yet concatnated with its B' feature from this level)
//s: For coherence search
//q: The coordinate in the b image where we're trying to find the best pixel
//l: the current multires level
//cFSize and cLSize are sizes of feature vectors at coarse level that are "full" and "l-shaped", respectively
//FSize and LSize are the same but for fine resolution images
static Coord findBestMatch(const R2Image* A, const R2Image* B, R2Image* Bp, double** AFeatures, ANNkd_tree* AFeatureTree,
						   double* BFeature, Coord* s, Coord q, int l, 
						   int cFSize, int FSize, int LSize) {
	int x = q.x;
	int y = q.y;

	int BpFeatureSize;
	double* BpFeature = getFeature(Bp, x, y, false, false, true, &BpFeatureSize);
	assert (BpFeatureSize == LSize);
	appendFeature(BFeature, cFSize*2 + FSize, BpFeature, LSize);
	delete[] BpFeature;//De-allocate since it's been appended to the parent feature

	Coord bestApproxCoord, bestCoherentCoord;

	double dApp;
	if (ANN) {
		int index[1];
		double dist[1];
		AFeatureTree->annkSearch(BFeature, 1, index, dist, ANNEps);
		dApp = dist[0];
		bestApproxCoord.x = index[0]%A->Width();
		bestApproxCoord.y = index[0]/A->Width();
	}
	else
		dApp = bruteForceNN(AFeatures, A, BFeature, cFSize*2+FSize+LSize, bestApproxCoord);
	double dCoh = getBestCoherent(A, B, AFeatures, BFeature, cFSize*2+FSize+LSize, s, q, bestCoherentCoord);
	//if (dCoh < dApp)
	//	printf("(%.3f, %.3f)\n", dCoh, dApp);
	if (dCoh <= dApp*(1 + pow(2.0, (double)(l-L))*Kappa))
		return bestCoherentCoord;
	return bestApproxCoord;
}

static void calculateLuminanceRemappingParams(const R2Image* A, const R2Image* B) {
	//static double sigL = 1.0, meanAL = 0.0, meanBL = 0.0;//Luminance remapping parameters
	meanAL = 0.0;
	meanBL = 0.0;
	double sigAL = 0.0;//Standard deviation in luminance
	double sigBL = 0.0;
	for (int x = 0; x < A->Width(); x++) {
		for (int y = 0; y < A->Height(); y++) {
			meanAL += A->Pixel(x, y).Luminance();
		}
	}
	meanAL /= (double)A->NPixels();
	for (int x = 0; x < A->Width(); x++) {
		for (int y = 0; y < A->Height(); y++) {
			double diff = A->Pixel(x,y).Luminance() - meanAL;
			sigAL += diff*diff;
		}
	}
	sigAL = sqrt(sigAL / (double)A->NPixels());
	for (int x = 0; x < B->Width(); x++) {
		for (int y = 0; y < B->Height(); y++) {
			meanBL += B->Pixel(x, y).Luminance();
		}
	}
	meanBL /= (double)B->NPixels();
	for (int x = 0; x < B->Width(); x++) {
		for (int y = 0; y < B->Height(); y++) {
			double diff = B->Pixel(x,y).Luminance() - meanBL;
			sigBL += diff*diff;
		}
	}
	sigBL = sqrt(sigBL / (double)B->NPixels());
	if (sigAL <= 0)	sigL = 1.0;//Prevent divide by zero
	else sigL = sigBL / sigAL;
}

static void printFeature(double* feature, int size) {
	printf("[");
	for (int j = 0; j < size; j++) {
		printf("%.3lf", feature[j]);
		if (j < size - 1)
			printf(", ");
	}
	printf("]\n");
}

static double getFeatureMag(double* feature, int size) {
	double mag = 0.0;
	for (int i = 0; i < size; i++)
		mag += feature[i]*feature[i];
	return sqrt(mag);
}

static R2Image *
CreateAnalogyImage(const R2Image *AImage, const R2Image *ApImage, const R2Image *BImage, GaussianPyramid& BpPyramid)
{
	if (AImage->Width() != ApImage->Width() || AImage->Height() != ApImage->Height()) {
		fprintf(stderr, "ERROR: Input images A and A' must have same dimension\n");
		exit(0);
	}

	if(luminanceRemapping)
		calculateLuminanceRemappingParams(AImage, BImage);

	GaussianPyramid APyramid((R2Image*)AImage, L);
	GaussianPyramid ApPyramid((R2Image*)ApImage, L);
	GaussianPyramid BPyramid((R2Image*)BImage, L);

	R2Image *A, *Ap, *B, *Bp;
	R2Image *Al = NULL, *Apl = NULL, *Bl = NULL, *Bpl = NULL;//Images one level below
	int cFSize = 0, FSize, LSize;

	for (int level = 0; level < L; level++) {
		A = APyramid.getImage(level);
		Ap = ApPyramid.getImage(level);
		B = BPyramid.getImage(level);
		if (level > 0) {
			Al = APyramid.getImage(level-1);
			Apl = ApPyramid.getImage(level-1);
			Bl = BPyramid.getImage(level-1);
			Bpl = BpPyramid.getImage(level-1);
		}

		int BWidth = B->Width(), BHeight = B->Height();
		//Allocate the new image Bp at this level
		Bp = new R2Image(BWidth, BHeight);
		BpPyramid.images[level] = Bp;

		//Allocate space for the "s" buffer, which stores which pixel matched best from A'
		Coord* s = new Coord[Bp->NPixels()];

		//Precompute features from last time at a coarser level, but only if there was
		//actually a last time (i.e. level > 0)
		double** AllAlFeatures = (level>0)?computeAllFeatures(Al, true, true, false, &cFSize):NULL;
		double** AllAplFeatures = (level>0)?computeAllFeatures(Apl, true, true, false, &cFSize):NULL;
		double** AllBlFeatures = (level>0)?computeAllFeatures(Bl, true, false, false, &cFSize):NULL;
		double** AllBplFeatures = (level>0)?computeAllFeatures(Bpl, true, false, false, &cFSize):NULL;

		printf("%i x %i\n", B->Width(), B->Height());
		//Precompute features at this level, which can be done for everything except Bp
		double** AllAFeatures = computeAllFeatures(A, false, true, false, &FSize);
		double** AllApFeatures = computeAllFeatures(Ap, false, true, true, &LSize);
		double** AllBFeatures = computeAllFeatures(B, false, false, false, &FSize);

		//Now Merge the features together
		double** AFeatures = new double*[A->NPixels()];
		double** BFeatures = new double*[B->NPixels()];
		for (int i = 0; i < A->NPixels(); i++) {
			AFeatures[i] = new double[cFSize*2 + FSize + LSize];
			if (level > 0) {
				//Use multires info
				//Figure out the closest position that's one level up (at half the resolution)
				//and use this as index j to choose from one level up
				int x = i % A->Width();
				int y = i / A->Width();
				int j = (x/2) + (y/2)*Al->Width();
				j = min(Al->NPixels() - 1, j);
				appendFeature(AFeatures[i], 0, AllAlFeatures[j], cFSize);
				appendFeature(AFeatures[i], cFSize, AllAplFeatures[j], cFSize);
			}
			appendFeature(AFeatures[i], cFSize*2, AllAFeatures[i], FSize);
			appendFeature(AFeatures[i], cFSize*2 + FSize, AllApFeatures[i], LSize);
		}
		ANNkd_tree* AFeatureTree = NULL;
		if (ANN) {
			if (verbose) printf("Constructing ANN tree\n");
			AFeatureTree = new ANNkd_tree(AFeatures, A->NPixels(), cFSize*2 + FSize + LSize);
			if (verbose) printf("Finished constructing ANN Tree\n");
		}

		for (int i = 0; i < B->NPixels(); i++) {
			BFeatures[i] = new double[cFSize*2 + FSize + LSize];
			if (level > 0) {
				int x = i % B->Width();
				int y = i / B->Width();
				int j = (x/2) + (y/2)*Bl->Width();
				j = min(Bl->NPixels() - 1, j);
				appendFeature(BFeatures[i], 0, AllBlFeatures[j], cFSize);
				appendFeature(BFeatures[i], cFSize, AllBplFeatures[j], cFSize);
			}
			appendFeature(BFeatures[i], cFSize*2, AllBFeatures[i], FSize);
		}

		//Clean up dynamic memory
		if (level > 0) {
			deallocateFeatureArray(AllAlFeatures, Al->NPixels());
			deallocateFeatureArray(AllAplFeatures, Apl->NPixels());
			deallocateFeatureArray(AllBlFeatures, Bl->NPixels());
			deallocateFeatureArray(AllBplFeatures, Bpl->NPixels());
		}
		deallocateFeatureArray(AllAFeatures, A->NPixels());
		deallocateFeatureArray(AllApFeatures, Ap->NPixels());
		deallocateFeatureArray(AllBFeatures, B->NPixels());

		printf("Finished pre-computing features for level %i\n", level);

		//Look at the pixels in scan-line order
		for (int y = 0; y < BHeight; y++) {
			if (verbose)	printf("%i  ", y);
			for (int x = 0; x < BWidth; x++) {
				Coord q = Coord(x, y);
				Coord p;
				if (y < spatialKFine/2) {
					//Fill in the first few scanLines to prevent the image from getting crap in the beginning
					p.x = (int)floor((double)(x*A->Width())/(double)B->Width()+0.5);
					p.y = (int)floor((double)(y*A->Height())/(double)B->Height());
				}
				else
					p = findBestMatch(A, B, Bp, AFeatures, AFeatureTree, BFeatures[x+y*B->Width()], s, q, level, cFSize, FSize, LSize);
				if (!useAColors) {
					//Set pixel in Bp to be the luminance of the pixel in Ap but keep colors in B 
					R2Pixel newPixel(B->Pixel(x, y));
					newPixel.SetYIQ(Ap->Pixel(p.x, p.y).Y(), newPixel.I(), newPixel.Q());
					Bp->SetPixel(x, y, newPixel);//B'l(q) = A'l(p)
					//Bp->SetPixel(x, y, B->Pixel(p.x, p.y));
				}
				else {
					//Copy the pixel directly over from Ap to Bp (useful for cases like emboss)
					Bp->SetPixel(x, y, Ap->Pixel(p.x, p.y));
				}
				pixelLocs.insert(p.x + p.y*A->Width());
				s[y*BWidth + x] = p;//sl(q) <--- p

				//printf("%.3lf\n", q.Dist(p));
			}
		}		
		delete[] s;
		if (verbose)
			printf("\n\n%i out of %i unique pixels drawn from A\n\n", (int)pixelLocs.size(), A->NPixels());
		pixelLocs.clear();
		//Clean up features for the next round
		deallocateFeatureArray(AFeatures, A->NPixels());
		deallocateFeatureArray(BFeatures, B->NPixels());
		if (ANN)	delete AFeatureTree;
	}//End Gaussian Pyramid loop

	// Return Bp image
	return Bp;
}

static Coord bruteForceNNHole(double** features, R2Image* im, int x, int y, int featureLen) {
	Coord bestCoord;
	double minNorm = FLT_MAX;
	int width = im->Width();
	int NFeatures = im->NPixels();
	int len;
	double* feature = getFeature(im, x, y, false, true, false, &len);
	assert (len == featureLen);
	for (int i = 0; i < NFeatures; i++) {
		double L2Dist = 0.0;
		int numCompared = 0;
		for (int k = 0; k < featureLen; k++) {
			if (feature[k] == FLT_MAX)
				continue;//Don't compare the blue spots
			if (features[i][k] == FLT_MAX) {
				//If one of the features in the codebook had a blue
				//pixel, don't even consider this feature
				L2Dist = FLT_MAX;
				break;
			}
			double diff = feature[k] - features[i][k];
			L2Dist += diff*diff;
			numCompared++;
		}
		if (numCompared < featureLen/4)
			continue;
		//Scale the distance by the number of compared components
		L2Dist *= (featureLen+1)/(numCompared+1);
		int coordX = i%width, coordY = i/width;
		if (L2Dist <= minNorm && !isMaskColor(im->Pixel(coordX, coordY))) {
			minNorm = L2Dist;
			bestCoord.x = coordX;
			bestCoord.y = coordY;
		}
	}
	return bestCoord;
}

static void fillBoundary(R2Image* im, int px, int py, double** features, int featureLen) {
	printf("\nFilling in hole\n");
	bool goingRight = true;
	int x = px, y = py;
	int width = im->Width();
	int height = im->Height();

	//Up, UpRight, Right, RightDown, Down  (continue going right)
	//Downleft, left, upleft (switch to going left)
	int rightDx[8] = {0, 1, 1, 1, 0, -1, -1, -1};
	int rightDy[8] = {1, 1, 0, -1, -1, -1, 0, 1};

	//Down, DownLeft, Left, UpLeft, Up (continue going left)
	//UpRight, Right, DownRight (switch to going right)
	int leftDx[8] = {0, -1, -1, -1, 0, 1, 1, 1};
	int leftDy[9] = {-1, -1, 0, 1, 1, 1, 0, -1};

	while (true) {
		if (verbose)
			printf("(%i, %i) ", x, y);
		//Fill in the pixel at (x, y)
		Coord p = bruteForceNNHole(features, im, x, y, featureLen);
		im->Pixel(x, y) = im->Pixel(p.x, p.y);
		//Now find the next pixel to go to
		int i;
		if (goingRight) {
			for (i = 0; i < 8; i++) {
				int newx = x+rightDx[i];
				int newy = y+rightDy[i];
				if (newx < 0 || newx >=width-1 || newy < 0 || newy>=height-1)
					continue;
				if (isMaskColor(im->Pixel(newx, newy))) {
					if (i >= 5)
						goingRight = false;
					x = newx;
					y = newy;
					break;
				}
			}
			if (i == 8) //No more connected pixels on boundary
				return;
		}
		else {
			for (i = 0; i < 8; i++) {
				int newx = x+leftDx[i];
				int newy = y+leftDy[i];
				if (newx < 0 || newx >=width-1 || newy < 0 || newy>=height-1)
					continue;
				if (isMaskColor(im->Pixel(newx, newy))) {
					if (i >= 5)
						goingRight = true;
					x = newx;
					y = newy;
					break;
				}
			}
			if (i == 8) //No more connected pixels on boundary
				return;
		}
	}
}	

static void fillHoles(R2Image* im) {
	int featureLen;
	double** features = computeAllFeatures(im, false, true, false, &featureLen);
	int width = im->Width(), height = im->Height();

	//Go in scan line order until a hole pixel is found
	for (int y = height-1; y >= 0; y--) {
		printf("%i ", y);
		for (int x = 0; x < width; x++) {
			if (isMaskColor(im->Pixel(x, y)))
				fillBoundary(im, x, y, features, featureLen);
		}
	}

	deallocateFeatureArray(features, im->NPixels());
}

static int 
ParseArgs(int argc, char **argv)
{
  // Parse program arguments 
  argv++, argc--; 
  while (argc > 0) {
    if ((*argv)[0] == '-') {
          if (!strcmp(*argv, "-mask_color")) { 
		mask_color.Reset(atof(argv[1]),atof(argv[2]),atof(argv[3]),1); 
		argv+=3; argc-=3; 
	  }
	  else if (!strcmp(*argv, "-verbose")) {verbose = true;}
	  else if (!strcmp(*argv, "-useAColors")) {useAColors = true;}
	  else if (!strcmp(*argv, "-bruteForce")) {ANN = false;}
	  else if (!strcmp(*argv, "-luminanceRemapping")) {luminanceRemapping = true;}
	  else if (!strcmp(*argv, "-noGaussianLuminance")) {noGaussianLuminance = true;}
	  else if (!strcmp(*argv, "-holeFilling")) {holeFilling = true;}
	  else if (!strcmp(*argv, "-steerableFilters")) {steerableFilters = true;}
	  else if (!strcmp(*argv, "-kappa")) { argv++; argc--; Kappa = atof(*argv); }
	  else if (!strcmp(*argv, "-ANNEps")) { argv++; argc--; ANNEps = atof(*argv); }
	  else if (!strcmp(*argv, "-levels")) { argv++; argc--; L = atoi(*argv); }
	  else if (!strcmp(*argv, "-outputPyramid")) { 
		outputPyramid = true;
		argv++; argc--;
		pyramidDir = *argv;
	  }
	  else { fprintf(stderr, "Invalid option: %s\n", *argv); return 0; }
    }
    else {
      if (!A_filename) A_filename = *argv;
      else if (!Ap_filename) Ap_filename = *argv;
      else if (!B_filename) B_filename = *argv;
      else if (!Bp_filename) Bp_filename = *argv;
      else { fprintf(stderr, "Invalid option: %s\n", *argv); return 0; }
    }
    argv++, argc--; 
  }

  // Check program arguments
  if ((!holeFilling & (!A_filename || !Ap_filename || !B_filename || !Bp_filename)) || holeFilling && (!A_filename || !Ap_filename)) {
    if (holeFilling)
		fprintf(stderr, "Usage: Analogy imagein imageout -holeFilling [other parameters]\n");
	else
		fprintf(stderr, "Usage: analogy A A\' B B\'[-mask_color r g b] [-useAColors] [-bruteForce] [-luminanceRemappling] [-noGaussianLuminance] [-steerableFilters] [-kappa <float coherence>] [-ANNEps <float>] [-levels <int>] [-outputPyramid <string directory+prefix>] [-verbose]\n");
    return 0;
  }

  // Return success
  return 1;
}



int 
main(int argc, char **argv)
{
	// Parse program arguments
	if (!ParseArgs(argc, argv)) exit(-1);

	clock_t start = clock(), finish;

	if (holeFilling) {
		R2Image* im = ReadImage(A_filename);
		if (!im) exit(-1);
		fillHoles(im);
		im->Write(Ap_filename);
	}
	else {
		// Read input images
		R2Image *A = ReadImage(A_filename);
		if (!A) exit(-1);
		R2Image *Ap = ReadImage(Ap_filename);
		if (!Ap) exit(-1);
		R2Image *B = ReadImage(B_filename);
		if (!B) exit(-1);

		GaussianPyramid BpPyramid(L);//Create an empty Gaussian Pyramid for the Bp
		//image which will be synthesized
		//Also allocate outside of the CreateAnalogyImage function because
		//that function deletes all of the image pyramids it creates

		// Create output image	  else if (!strcmp(*argv, "-levels")) { argv++; argc--; L = atoi(*argv); }
		R2Image *Bp = CreateAnalogyImage(A, Ap, B, BpPyramid);
		if (!Bp) exit(-1);

		// Write output image
		if (!Bp->Write(Bp_filename)) exit(-1);

		if (outputPyramid)
			BpPyramid.writeImages(string(pyramidDir));
	}

	finish = clock();
	printf("Elapsed time = %f sec\n", (double(finish)-double(start))/CLOCKS_PER_SEC);

	/*R2Image* A = ReadImage(argv[1]);
	GaussianPyramid pyr(A, 5);
	printf("Finished contructing gaussian pyramid\n");
	pyr.writeImages("pyramid\\level");*/

	// Return success
	return 0;
}
