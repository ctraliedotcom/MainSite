#include "SegImage.h"
#include <stdio.h>
#include <vector>
extern "C" {
#include "jpeglib.h"
}
#include "CImg.h"
#define PI 3.1415925
using namespace cimg_library;
using namespace std;


static CImg<unsigned char> invDCTSlow(double** coeffs, int blockWidth, int blockHeight) {
	CImg<unsigned char> ret(blockWidth*8, blockHeight*8);
	CImgDisplay display(ret, "DCT Debugger");
	for (int blockRow = 0; blockRow < blockHeight; blockRow++) {
		for (int blockCol = 0; blockCol < blockWidth; blockCol++) {
			int index = blockRow*blockWidth + blockCol;
			double* coefficients = coeffs[index];
			//coefficients[0] = coefficients[0] + last[k];
			//last[k] = coefficients[0];
			int xoff = blockCol*8, yoff = blockRow*8;
			for(int x=0; x<8; x++){
				for(int y=0; y<8; y++){
					double val = 0.0;
					for(int p=0; p<64; p++){
						int u = p%8;
						int v = p/8;
						double coefficient = (double)((short int)(coefficients[p]));	
						val += ((p==0)?0.125:0.25)* coefficient*
								cos( (2.0*(double)x + 1.0)*u*PI/16.0 )*
								cos( (2.0*(double)y + 1.0)*v*PI/16.0 );
					}
					if (val <= 255 && val >= 0) {
						unsigned char vali = (unsigned char)val;
						unsigned char color[3] = {vali, vali, vali};
						ret.draw_rectangle(xoff+x, yoff+y, xoff+x+1, yoff+y+1, color);
					}
    			}
			}
		}
		ret.display(display);
	}
	return ret;
}

//Extract the DCT coefficients directly from the JPEG file using
//the open source JPEGLIB library
//Return the width and height (by reference)
static double** getYDCTCoeffs(char* filename, int* blockWidth, int* blockHeight) {
	FILE* jpegIn;
	struct jpeg_decompress_struct cinfo;
	struct jpeg_error_mgr jerr;
	cinfo.err = jpeg_std_error(&jerr);
	jpeg_create_decompress(&cinfo);

	if ((jpegIn = fopen(filename, "rb")) == NULL) {
		fprintf(stderr, "can't open %s\n", filename);
		exit(1);
	}
	jpeg_stdio_src(&cinfo, jpegIn);
	jpeg_read_header(&cinfo, TRUE);
	jvirt_barray_ptr* dctArrays = jpeg_read_coefficients(&cinfo);
	//NOTE: Component 0 is the Y component that I care about
	//for (int i = 0; i < cinfo.num_components; i++) {
	int i = 0;
	JBLOCKARRAY buffer;
	JCOEFPTR blockPtr;
	jpeg_component_info* compInfo;
	JDIMENSION blockRow, blockCol;
	compInfo = cinfo.comp_info+i;
	*blockWidth = compInfo->width_in_blocks;
	*blockHeight = compInfo->height_in_blocks;
	double** ret = new double*[(*blockWidth)*(*blockHeight)];
	for (blockRow = 0; blockRow < (JDIMENSION)*blockHeight; blockRow++) {
		buffer = (cinfo.mem->access_virt_barray)((j_common_ptr)&cinfo,
					dctArrays[i], blockRow, (JDIMENSION)1, FALSE);

		for (blockCol = 0; blockCol < (JDIMENSION)*blockWidth; blockCol++) {
			blockPtr = buffer[0][blockCol];
			int index = blockRow*(*blockWidth) + blockCol;
			ret[index] = new double[DCTSIZE2];
			for (int dctCell = 0; dctCell < DCTSIZE2; dctCell++)
				ret[index][dctCell] = (double)blockPtr[dctCell];
		}
	}
	//}
	jpeg_destroy_decompress(&cinfo);
	return ret;
}

static void freeDCTCoeffs(double** dctCoeffs, int blockWidth, int blockHeight) {
	for (int i = 0; i < blockWidth*blockHeight; i++)
		delete[] dctCoeffs[i];
	delete[] dctCoeffs;
}

//Return f_ac
static double getf_ac(double* coeffs) {
	double f_ac = 0.0;
	for (int v = 0; v < 4; v++) {
		for (int u = 0; u < 4; u++) {
			int index = v*8+u;
			f_ac += (u*u+v*v)*abs(coeffs[index]);
		}
	}
	return f_ac;
}

SegImage::SegImage(char* dirName, int frame) {
	char filename[512];
	sprintf(filename, "%s\\%i.jpg", dirName, frame);
	dctCoeffs = getYDCTCoeffs(filename, &blockWidth, &blockHeight);
	image = new CImg<unsigned char>(filename);
	f_acArr = new double[blockWidth*blockHeight];
	classifications = new int[blockWidth*blockHeight];
	for (int blockRow = 0; blockRow < blockHeight; blockRow++) {
		for (int blockCol = 0; blockCol < blockWidth; blockCol++) {
			int index = blockRow*blockWidth + blockCol;	
			f_acArr[index] = getf_ac(dctCoeffs[index]);
		}
	}
}

SegImage::~SegImage() {
	freeDCTCoeffs(dctCoeffs, blockWidth, blockHeight);
	delete image;
	delete[] f_acArr;
	delete[] classifications;
}

void SegImage::drawClassificationResults() {
	for (int blockRow = 0; blockRow < blockHeight; blockRow++) {
		for (int blockCol = 0; blockCol < blockWidth; blockCol++) {
			int index = blockRow*blockWidth + blockCol;
			int xoff = blockCol*8, yoff = blockRow*8;
			if (classifications[index] == 0)
				continue;//Not a special block
			int total = 0;
			int zeros = 0;
			if (blockCol > 0) {
				total++;
				if (classifications[blockRow*blockWidth + blockCol-1] == 0)
					zeros++;
			}
			if (blockCol < blockWidth - 1) {
				total++;
				if (classifications[blockRow*blockWidth + blockCol+1] == 0)
					zeros++;
			}
			if (blockRow > 0) {
				total++;
				if (classifications[(blockRow-1)*blockWidth + blockCol] == 0)
					zeros++;
			}
			if (blockRow < blockHeight - 1) {
				total++;
				if (classifications[(blockRow+1)*blockWidth + blockCol] == 0)
					zeros++;
			}
			if (total != zeros) {
				unsigned char* color;
				int channel = -1;
				if (classifications[index] == 1) {
					//1-AC threshold passed only
					color = c_blue;
					channel = 2;
				}
				else if (classifications[index] == 2) {
					//2-DC threshold passed only			
					color = c_green;
					channel = 1;
					continue;
				}
				else if (classifications[index] == 3) {
					//3-Both AC and DC thresholds passed
					color = c_red;
					channel = 0;
				}
				//Draw a cross in the block to indicate its type
				image->draw_line(xoff, yoff, xoff+7, yoff+7, color);
				image->draw_line(xoff+7, yoff, xoff, yoff+7, color);
				/*for (int dx = 0; dx < 8; dx++) {
					for (int dy = 0; dy < 8; dy++) {
						unsigned char pix[3];
						for (int k = 0; k < 3; k++)
							pix[k] = image->atXY(xoff+dx, yoff+dy, 0, k);
						pix[channel] = 255;
						image->draw_point(xoff+dx, yoff+dy, pix);
					}
				}*/
			}
		}
	}
}