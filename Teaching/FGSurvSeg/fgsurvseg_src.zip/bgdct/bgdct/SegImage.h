#ifndef SEGIMAGE_H
#define SEGIMAGE_H

#include "CImg.h"
using namespace cimg_library;
using namespace std;

static unsigned char c_red[3] = {255, 0, 0};
static unsigned char c_blue[3] = {0, 255, 0};
static unsigned char c_green[3] = {0, 0, 255};

class SegImage {
public:
	SegImage(char* dirName, int frame);
	~SegImage();
	void drawClassificationResults();

	double** dctCoeffs;
	double* f_acArr;
	//"classification" is used to classify a block as fg/bg
	//0-no thresholds passed
	//1-AC threshold passed only
	//2-DC threshold passed only
	//3-Both AC and DC thresholds passed
	int* classifications;
	int blockWidth, blockHeight;
	CImg<unsigned char>* image;
};


#endif