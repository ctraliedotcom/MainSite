#include "CImg.h"
#include "SegImage.h"
#include <algorithm>
#include <assert.h>

using namespace cimg_library;
using namespace std;

#define DELTA_AC 0.25
#define DELTA_DC 0.25

static bool sizeFiltering = false;
static bool outputRes = true;
static double alphaMu = 0.01;
static double alphaMuMax = 0.05;
static double alphaSig = 0.01;

double getMedian(double* a, int N) {
	double* b = new double[N];
	for (int i = 0; i < N; i++)
		b[i] = a[i];
	sort(b, b+N);
	double med;
	if (N%2 == 1)
		med = b[N/2];
	else
		med = (b[N/2-1] + b[N/2])/2.0;
	delete[] b;
	return med;
}

//Used to fill in the "robust estimator" for mean (u) and standard deviation (sig)
//for either an AC or a DC coefficient feature in a block
//This is described in section 2.3 of "segmentation-zhu"
void fillMeanMedian(double* u, double* sig, int index, double* fValues, int N) {
	assert (N > 1);
	double med = getMedian(fValues, N);
	double* medAbsDiffArr = new double[N];
	for (int frame = 0; frame < N; frame++)
		medAbsDiffArr[frame] = abs(fValues[frame] - med);
	double medAbsDiff = getMedian(medAbsDiffArr, N);
	u[index] = med;
	sig[index] = 1.4862*(1.0 + 5.0/(double)(N-1))*medAbsDiff;
	delete[] medAbsDiffArr;
}

SegImage** getInitialImages(char* dirName, int N) {
	SegImage** images = new SegImage*[N];
	for (int frame = 0; frame < N; frame++)
		images[frame] = new SegImage(dirName, frame+1);
	return images;
}


//Loop through the first N=20 frames to estimate distribution of blocks
SegImage** initDistributions(SegImage** images, double* uac, double* sigac, double* udc, double* sigdc, int blockWidth, int blockHeight, int N) {
	double* f_acValues = new double[N];
	double* f_dcValues = new double[N];
	for (int blockRow = 0; blockRow < blockHeight; blockRow++) {
		for (int blockCol = 0; blockCol < blockWidth; blockCol++) {
			int index = blockRow*blockWidth + blockCol;
			for (int frame = 0; frame < N; frame++) {
				f_acValues[frame] = images[frame]->f_acArr[index];
				f_dcValues[frame] = images[frame]->dctCoeffs[index][0];
			}
			fillMeanMedian(uac, sigac, index, f_acValues, N);
			fillMeanMedian(udc, sigdc, index, f_dcValues, N);
		}
	}
	//Free up dynamic memory
	delete[] f_acValues;
	delete[] f_dcValues;
	return images;
}

void parseOptions(int argc, char** argv) {
	argc -= 4;
	argv += 4;
	while (argc > 0) {
		if (!strcmp(*argv, "-sizeFiltering")) {
			sizeFiltering = true;
			argc--;argv++;
		}
		else if (!strcmp(*argv, "-alphaMu")) {
			argc--;argv++;
			alphaMu = atof(*argv);
			argc--;argv++;
		}
		else if (!strcmp(*argv, "-alphaSig")) {
			argc--;argv++;
			alphaSig = atof(*argv);
			argc--;argv++;
		}
		else if (!strcmp(*argv, "-noOutput")) {
			outputRes = false;
			argc--;argv++;
		}
		else {
			fprintf(stderr, "Unrecognized parameter %s\n", *argv);
			exit(0);
		}
	}
}

int main(int argc, char** argv) {
	if (argc < 4) {
		fprintf(stderr, "Usage: bgdct <video_directory> <out directory> <numframes> [options]\n");
		return 1;
	}
	parseOptions(argc, argv);
	char* dirName = argv[1];
	char* outDir = argv[2];
	int numFrames = atoi(argv[3]);
	int N = 20;
	if (numFrames < N) {
		fprintf(stderr, "ERROR: Fewer than %i frames (not enough for initial training)\n", N);
		return 1;
	}
	
	SegImage im0(dirName, 1);
	int blockWidth = im0.blockWidth;
	int blockHeight = im0.blockHeight;
	int nblocks = blockWidth*blockHeight;
	double* uac = new double[nblocks];
	double* sigac = new double[nblocks];
	double* udc = new double[nblocks];
	double* sigdc = new double[nblocks];
	SegImage** images = getInitialImages(dirName, N);
	initDistributions(images, uac, sigac, udc, sigdc, blockWidth, blockHeight, N);

	//Once the initial parameters have been determined, begin to draw video
	char title[512];
	sprintf(title, "DCT Foreground Segmentation of %s", argv[1]);
	CImg<unsigned char> canvas(*(im0.image));
	CImgDisplay display(canvas, title);
	for (int i = 0; i < N; i++) {
		canvas.draw_image(0, 0, *(images[i]->image));
		canvas.display(display);
	}
	int fastUpdateFrame = 0;
	for (int frame = N; frame < numFrames; frame++) {
		//Delete the oldest image and push a new image on the end
		delete images[0];
		for (int i = 0; i < N-1; i++)
			images[i] = images[i+1];
		SegImage* image = new SegImage(dirName, frame+1);
		int fgCount = 0;
		images[N-1] = image;
		for (int blockRow = 0; blockRow < blockHeight; blockRow++) {
			for (int blockCol = 0; blockCol < blockWidth; blockCol++) {
				int index = blockRow*blockWidth + blockCol;
				double meanAC = uac[index];
				double stdAC = sigac[index];
				double meanDC = udc[index];
				double stdDC = sigdc[index];
				double Tac = DELTA_AC*meanAC + 2.5*stdAC;
				double Tdc = DELTA_DC*meanDC + 2.5*stdDC;
				int classification = 0;
				double f_ac = image->f_acArr[index];
				double f_dc = image->dctCoeffs[index][0];
				if (abs(f_ac - meanAC) > Tac)
					classification += 1;
				if (abs(f_dc - meanDC) > Tdc)
					classification += 2;
				if (classification > 0)
					fgCount++;
				image->classifications[index] = classification;
				
				//if (image->classifications[index] != 3) {
					//Update the distributions based on this frame if it's not a foreground block
					uac[index] = (1.0-alphaMu)*meanAC + alphaMu*image->f_acArr[index];
					udc[index] = (1.0-alphaMu)*meanDC + alphaMu*image->dctCoeffs[index][0];
					double diff = image->f_acArr[index] - meanAC;
					sigac[index] = (1.0-alphaSig)*stdAC*stdAC + alphaSig*diff*diff;
					diff = image->dctCoeffs[index][0] - meanDC;
					sigdc[index] = (1.0-alphaSig)*stdDC*stdDC + alphaSig*diff*diff;
					sigac[index] = sqrt(sigac[index]);
					sigdc[index] = sqrt(sigdc[index]);
				//}
			}
		}
		if ((double)fgCount / (double)(blockWidth*blockHeight) > 0.4) {
			//Fast update needed
			fastUpdateFrame = frame;
		}

		if (frame == fastUpdateFrame + N) {
			printf("FAST UPDATE\n");
			initDistributions(images, uac, sigac, udc, sigdc, blockWidth, blockHeight, N);
		}

		image->drawClassificationResults();
		if (outputRes) {
			char outName[512];
			sprintf(outName, "%s\\%i.bmp", outDir, frame-20);
			image->image->save(outName);
			/*char command[512];
			sprintf(command, "convert %s\\%i.bmp %s\\%i.jpg", outDir, frame, outDir, frame);
			system(command);
			sprintf(command, "del %s\\%i.bmp", outDir, frame);
			system(command);*/
		}
		canvas.draw_image(0, 0, *(image->image));
		canvas.display(display);
	}
	return 0;
}