$filename = $ARGV[0];
$outdir = $ARGV[1];
$startframe = $ARGV[2];
$endframe = $ARGV[3];

print "$filename\n$outdir\n$startframe\n$endframe\n\n\n";

if (!(-d $outdir)) { mkdir $outdir; }
$command = "ffmpeg -i $filename $outdir/"."\%"."d.png";
print $command."\n";
`$command`;

if ($startframe == 0) {
	$startframe = 1;
}
if ($endframe == 0) {
	open my($dh), $outdir or die "Couldn't open dir '$outdir': $!";
	@files = readdir $dh;
	$endframe = $#files+1;
	print "\n\nendframe = $endframe\n\n";
	closedir $dh;
}

for ($i = $startframe; $i <= $endframe; $i++) {
	$new = $i - $startframe + 1;
	`convert $outdir/$i.png $outdir/$new.jpg`;
}

`rm $outdir/*.png`;