#include "CImg.h"
#include "MOGTracker.h"
#include <algorithm>
#include <assert.h>

using namespace cimg_library;
using namespace std;

static int N = 5;//Number of gaussians in each MOG
static double Alpha = 0.01;
static double T = 0.7;
static bool outputRes = true;

void parseOptions(int argc, char** argv) {
	argc -= 4;
	argv += 4;
	while (argc > 0) {
		if (!strcmp(*argv, "-N")) {
			argc--;argv++;
			N = atoi(*argv);
			argc--;argv++;
		}
		if (!strcmp(*argv, "-Alpha")) {
			argc--;argv++;
			Alpha = atof(*argv);
			argc--;argv++;
		}
		else if (!strcmp(*argv, "-noOutput")) {
			outputRes = false;
			argc--;argv++;
		}
		else {
			fprintf(stderr, "Unrecognized parameter %s\n", *argv);
			exit(0);
		}
	}	
}

char* getName(char* buf, char* dir, int num, char* type) {
	sprintf(buf, "%s\\%i.%s", dir, num, type);
	return buf;
}

int main(int argc, char** argv) {
	if (argc < 4) {
		fprintf(stderr, "Usage: bgmog <video_directory> <out directory> <numframes> [options]\n");
		return 1;
	}
	parseOptions(argc, argv);
	char* dirName = argv[1];
	char* outDir = argv[2];
	int numFrames = atoi(argv[3]);
	char filenameBuf[512];

	char title[512];
	sprintf(title, "MOG Foreground Segmentation of %s", argv[1]);

	CImg<unsigned char> im1(getName(filenameBuf, dirName, 1, "jpg"));
	int width = im1.width(), height = im1.height();
	MOGTracker tracker(width, height, Alpha, T, N);

	CImg<unsigned char> canvas(im1);
	CImgDisplay display(canvas, title);

	for (int frame = 1; frame <= numFrames; frame++) {
		CImg<unsigned char> im(getName(filenameBuf, dirName, frame, "jpg"));
		tracker.update(im);
		canvas.draw_image(0, 0, im);
		canvas.display(display);
		if (outputRes)
			im.save(getName(filenameBuf, outDir, frame, "bmp"));
	}

	return 0;
}