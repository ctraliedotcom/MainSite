#ifndef MOG_TRACKER_H
#define MOG_TRACKER_H

#include "CImg.h"
using namespace cimg_library;
#define PI 3.1415925

class MOG {
public:
	MOG();
	~MOG();
	double* Sig2;//Squared variance
	double* meanR;
	double* meanG;
	double* meanB;
	double* weight;

	double getProb(int index, double rSquared);
	void normalizeWeights();
	void updateDistribution(int index, double Rho, double xR, double xG, double xB, double rSquared);
	int getLeastProbableIndex();
};

class MOGTracker {
public:
	MOGTracker(int w, int h, double A, double tParam, int nParam);
	~MOGTracker();
	void update(CImg<unsigned char>& img);

	int width, height;
	double Alpha;
	double T;
	MOG* pixelMOGs;
};

#endif