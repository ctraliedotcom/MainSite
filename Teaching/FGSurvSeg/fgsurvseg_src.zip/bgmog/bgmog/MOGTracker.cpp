#include "MOGTracker.h"
#include "Cimg.h"
#include <algorithm>
using namespace cimg_library;
using namespace std;

class Peak {
public:
	int index;
	double peak;
};

//Want them to be sorted in descending order of probability
bool Comparator(Peak* p1, Peak* p2) {
	return p1->peak > p2->peak;
}

//Parameters obtained from "Understanding Background Mixture Models for Foreground Segmentation"
int N = -1;//Number of models
double wInit = 0.05;
double sigSquaredInit = 30*30;
double Lambda = 2.5;//Number of standard deviations for detecting a "match"
static Peak** peaks = NULL;

MOG::MOG() {
	Sig2 = new double[N];
	meanR = new double[N];
	meanG = new double[N];
	meanB = new double[N];
	weight = new double[N];
	for (int i = 0; i < N; i++) {
		Sig2[i] = sigSquaredInit;
		weight[i] = 1.0 / (double)N;
		if (i == 0) {meanR[i] = 255; meanG[i] = 0; meanB[i] = 0;}
		else if (i == 1) {meanR[i] = 0; meanG[i] = 255; meanB[i] = 0;}
		else if (i == 2) {meanR[i] = 0; meanG[i] = 0; meanB[i] = 255;}
		else if (i == 3) {meanR[i] = 0; meanG[i] = 0; meanB[i] = 0;}
		else if (i == 4) {meanR[i] = 255; meanG[i] = 255; meanB[i] = 255;}
	}
}

MOG::~MOG() {
	delete[] Sig2;
	delete[] meanR;
	delete[] meanG;
	delete[] meanB;
	delete[] weight;
}

double MOG::getProb(int index, double rSquared) {
	double sigSquared = Sig2[index];
	double prob = exp(-rSquared / (2.0*sigSquared));
	prob /= pow(2*PI*sqrt(sigSquared), 1.5);
	return prob;
}

void MOG::normalizeWeights() {
	double total = 0.0;
	for (int i = 0; i < N; i++)
		total += weight[i];
	for (int i = 0; i < N; i++)
		weight[i] /= total;
}

void MOG::updateDistribution(int index, double Rho, double xR, double xG, double xB, double rSquared) {
	meanR[index] = (1-Rho)*meanR[index] + Rho*xR;
	meanG[index] = (1-Rho)*meanG[index] + Rho*xG;
	meanB[index] = (1-Rho)*meanB[index] + Rho*xB;
	Sig2[index] = (1-Rho)*Sig2[index] + Rho*rSquared;
}

int MOG::getLeastProbableIndex() {
	int leastProbable = 0;
	double leastW = weight[0];
	for (int i = 0; i < N; i++) {
		if (weight[i] < leastW) {
			leastProbable = i;
			leastW = weight[i];
		}
	}
	return leastProbable;
}


MOGTracker::MOGTracker(int w, int h, double A, double tParam, int nParam) {
	N = nParam;
	width = w;
	height = h;
	pixelMOGs = new MOG[w*h];
	Alpha = A;
	T = tParam;
	if (peaks == NULL) {
		peaks = new Peak*[N];
		for (int i = 0; i < N; i++)
			peaks[i] = new Peak();
	}
}

MOGTracker::~MOGTracker() {
	delete[] pixelMOGs;
}

void MOGTracker::update(CImg<unsigned char>& img) {
	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++) {
	//for (int y = 400; y == 400; y++) {
	//	for (int x= 400; x == 400; x++) {
			int index = y*width+x;
			MOG* mog = &pixelMOGs[index];
			unsigned char pix[3];
			for (int k = 0; k < 3; k++)
				pix[k] = img.atXY(x, y, 0, k);
			//Stores information about the "matched" distribution
			double largestMOGPeak = 0.0;//(weight / STDev)
			double rSquared;
			int smallestMOGIndex = -1;
			for (int i = 0; i < N; i++) {
				double dR = pix[0] - mog->meanR[i];
				double dG = pix[1] - mog->meanG[i];
				double dB = pix[2] - mog->meanB[i];
				double dist2 = dR*dR + dG*dG + dB*dB;
				double numSTDevs = sqrt(dist2/mog->Sig2[i]);
				if (numSTDevs < Lambda) {
					//If a gaussian is within Lambda standard deviations of this example
					double peak = mog->weight[i] / sqrt(mog->Sig2[i]);
					if (peak > largestMOGPeak) {
						largestMOGPeak = peak;
						smallestMOGIndex = i;
						rSquared = dist2;
					}
				}
			}
			if (smallestMOGIndex == -1) {
				//printf("Adding new model ");
				//None of the distributions "match"; replace least probable
				//distribution with current value as its mean and an initially high variance
				int i = mog->getLeastProbableIndex();
				mog->weight[i] = wInit;
				mog->Sig2[i] = sigSquaredInit;
				mog->meanR[i] = pix[0];
				mog->meanG[i] = pix[1];
				mog->meanB[i] = pix[2];
				smallestMOGIndex = i;
				double dR = pix[0] - mog->meanR[i];
				double dG = pix[1] - mog->meanG[i];
				double dB = pix[2] - mog->meanB[i];
				rSquared = dR*dR + dG*dG + dB*dB;
			}
			
			if (x == 340 && y == 120) {
				//printf("%g ", mog->weight[smallestMOGIndex]);
			}

			//printf("%i (weight = %g): ", smallestMOGIndex, mog->weight[smallestMOGIndex]);
			//Adjust the prior weights and normalize
			for (int i = 0; i < N; i++) {
				mog->weight[i] = (1-Alpha)*mog->weight[i];
				if (i == smallestMOGIndex)
					mog->weight[i] += Alpha;
			}
			//Normalize
			mog->normalizeWeights();

			//Update matched distribution
			double prob = mog->getProb(smallestMOGIndex, rSquared);
			double Rho = Alpha*prob;
			mog->updateDistribution(smallestMOGIndex, Rho, pix[0], pix[1], pix[2], rSquared);

			//Sort distributions by peak and segment FG and BG
			for (int i = 0; i < N; i++) {
				peaks[i]->index = i;
				peaks[i]->peak = mog->weight[i] / sqrt(mog->Sig2[i]);
			}
			sort(peaks, peaks+N, Comparator);
			bool foreground = false;
			double accum = 0.0;
			for (int i = 0; i < N; i++) {
				int model = peaks[i]->index;
				if (model == smallestMOGIndex) {
					if (accum > T)
						foreground = true;
					break;
				}
				accum += mog->weight[model];
			}
			if (foreground) {
				pix[1] = 255;//Highlight foreground objects in green
				img.draw_point(x, y, pix);
			}
		}//End x loop
	}//End y loop
}