loc=strcat(TLDIR,'examples/labs/res/signalmasterset.mat');
load(loc);