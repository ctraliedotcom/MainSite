rastamat
===========

This is not my code!  It computes MFCC features for the delay series (related to timbre) in a standard way.  Download here
http://labrosa.ee.columbia.edu/matlab/rastamat/
