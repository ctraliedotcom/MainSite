chroma-asyn
===========

This is not my code!  It computes chroma features for the delay series (related to pitch).  Download here
http://labrosa.ee.columbia.edu/matlab/chroma-ansyn/
