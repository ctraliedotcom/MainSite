public class Coord {
	public int x, y;

	public Coord() {
		x = 0;
		y = 0;
	}

    public Coord(int x, int y) {
    	this.x = x;
    	this.y = y;
    }
}